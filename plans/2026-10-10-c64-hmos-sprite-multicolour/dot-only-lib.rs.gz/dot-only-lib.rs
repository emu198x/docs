//! MOS 6569/8565 PAL and 6567/8562 NTSC VIC-II video chip.
//!
//! The VIC-II is the C64's video chip. It drives the dot clock, owns
//! video memory reads, renders text / bitmap / sprites to an ARGB
//! framebuffer, steals CPU cycles during bad lines and sprite DMA,
//! and generates raster / collision / light-pen interrupts.
//!
//! Each [`Vic::tick`] advances one `phi2` cycle and renders 8 pixels.
//! This first fresh-workspace port keeps the archived crate's proven
//! raster, badline, sprite-BA, IRQ, and display-mode behaviour.

#![allow(clippy::cast_possible_truncation)]

pub mod oracle;
pub mod palette;
// Draw-stage sprite sequencer — first increment of the sprite-sequencer port,
// landed isolated and unit-tested before being wired into the renderer. Its API
// is exercised only by its own tests until the wiring increment, so the
// not-yet-used warning is expected and gated here deliberately.
#[allow(dead_code)]
mod sprite_sequencer;
// Sprite fetch chain (MC/MCBASE/exp-flop + crunch) — the addressing/height half
// of the real sprite hardware, landed isolated + unit-tested (S4a) before being
// wired to feed the sequencer (S4b). Exercised only by its own tests until then.
#[allow(dead_code)]
mod sprite_fetch_chain;

use sprite_fetch_chain::SpriteFetchChain;
use sprite_sequencer::{SpritePixel, SpriteSequencer};

use serde::{Deserialize, Serialize};
use serde_big_array::BigArray;

use palette::PALETTE;

/// Frame routing version. Bumped when the rendering path through this
/// chip (pixel pipeline, badline DMA accounting, sprite mux, display
/// mode dispatch, border timing, palette mapping) changes in a way
/// that invalidates previously-captured frame hashes in the C64
/// catalogue. The catalogue manifest carries the version each hash was
/// captured against; a mismatch fails loud with a re-capture
/// instruction.
///
/// **Version 1** (2026-05-20): per-phi2 8-pixel renderer with `tick`
/// advancing one cycle; standard/MCM/ECM text + MCM/hi-res bitmap
/// modes; sprite DMA pre-allocated per active sprite; PAL 312-line
/// frame, NTSC 263-line; palette from `palette::PALETTE`. The
/// pre-Seam-1 VIC-II described in
/// `knowledge/decisions/c64-architecture-review.md`.
///
/// **Version 2** (2026-07-01): sprite rendering switched from the geometry
/// `overlay_sprites` mux to the draw-stage shift-register **sprite sequencer**
/// (VICE `draw_sprites` two-stage model — MC/MCBASE/exp-flop fetch chain +
/// per-pixel DMA halt). Sprite pixels shift by sub-pixel timing and the
/// fetch/crunch/fetch-bug edge cases now match VICE, so any catalogue frame
/// carrying sprites re-hashes. See the sprite-sequencer increment in
/// `docs/plans/2026-06-30-c64-vic-ii-vc-vcbase-rc-rewrite.md`.
///
/// **Version 3** (2026-08-08): display g-access observes the entering Phi1
/// idle state before a late badline changes state on Phi2. VC/VMLI then
/// advance before the paired c-access only when that g-access was active.
/// Rendering consumes the same pre-increment VMLI and generates fresh idle or
/// graphics pixels beneath an opened vertical border instead of retaining the
/// previous frame's border pixels.
///
/// **Version 4** (2026-08-08): aggregate BA now has an explicit three-cycle
/// handover to AEC. Forced badlines store the disconnected `$FF` matrix byte
/// and the sampled CPU-side colour nibble until the fourth consecutive BA-low
/// cycle; ordinary badlines retain their cycles 12-14 lead and valid cycle-15
/// access. The C64 machine supplies the CPU Phi2 byte through `VicPhi2Bus`.
///
/// **Version 5** (2026-08-08): a cycle-53 `$D011` write that creates a badline
/// carries its post-VIC completion phase into the following VIC tick. The one
/// remaining far-edge matrix-DMA slot can no longer reopen as a second access
/// through the ordinary cycle-54 predicate.
///
/// **Version 6** (2026-08-08): a forced badline leaves the graphics output on
/// the two cells already resident in the VIC-II's C/V/G pipeline. At the
/// far-right edge this keeps both exposed cells on idle data even though Phi2
/// has already changed the internal display state and attempted its final
/// matrix access. The one displaced C-data entry is carried into the next
/// RC-zero display line instead of permanently corrupting the row buffer.
///
/// **Version 7** (2026-08-13): the far-edge forced-badline path uses Hoxs64's
/// bounded 12-bit C-data carry network instead of restoring one
/// fixture-specific matrix byte. Two output cells remain hidden, while only
/// the first following G-access suppresses the VC/VMLI advance.
///
/// **Version 8** (2026-10-06): the CPU sees the raster edge, raster IRQ and
/// badline/vertical-border counter on cycle 1 (stage 3a-A), write rules,
/// sprite DMA and the light pen follow VICE's cycles (3a-B), and a two-tick
/// colour stage resolves colour registers and the side border at VICE's
/// phase, with sprites under the border and zero graphics shifted out
/// beside the fetch window (3a-C).
///
/// **Version 9** (2026-10-07): the graphics sequencer loads each cell at the
/// XSCROLL that stands after the CPU access of the cell's g-access cycle,
/// instead of one XSCROLL latched per line, so a mid-line `$D016` write moves
/// the rest of the line (#1620).
///
/// **Version 10** (2026-10-07): the graphics sequencer decodes the display
/// mode at the shift register's output, so a mid-line mode change takes
/// effect at a fixed dot of the cycle instead of moving with XSCROLL, and
/// the g-access address reads some mode bits a cycle late (#1660).
///
/// **Version 11** (2026-10-07): outside the display window and under the
/// vertical border the sequencer keeps shifting out zero graphics with the
/// last g-access's matrix and colour entries, so an opened border shows the
/// last character's background instead of `$D021` (#1661).
pub const FRAME_ROUTING_VERSION: u32 = 11;

/// CPU-side data visible during the VIC-II's Phi2 phase.
///
/// The machine resolves this value from the live CPU address/data pins before
/// ticking the VIC-II. Keeping it as a sampled value leaves the video chip
/// independent of the CPU implementation while making bus ownership explicit.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct VicPhi2Bus {
    /// Byte currently supplied by the CPU side of the shared data bus.
    pub cpu_data: u8,
}

const PAL_FIRST_VISIBLE_LINE: u16 = 0;
const PAL_LAST_VISIBLE_LINE: u16 = 312;
// Like PAL, NTSC renders the full frame (every raster line) and leaves cropping
// to the consumer. Calibration against VICE's 6567R8 reference confirmed our
// NTSC content is horizontally pixel-aligned (crop dx=16, same as PAL) and
// matches ~99% on the overlapping rows; VICE's own 247-line visible window
// wraps the frame boundary, which a single first..last range can't express, so
// we render everything rather than pre-crop to an arbitrary sub-window.
const NTSC_FIRST_VISIBLE_LINE: u16 = 0;
const NTSC_LAST_VISIBLE_LINE: u16 = 263;
const FIRST_VISIBLE_CYCLE: u8 = 10;
const LAST_VISIBLE_CYCLE: u8 = 62;
const VISIBLE_CYCLES: u8 = LAST_VISIBLE_CYCLE - FIRST_VISIBLE_CYCLE;
/// Dot clock of the PAL VIC-II: eight pixels per 985,248 Hz cycle.
/// Reproduces the published 0.9365 pixel aspect.
pub const PAL_DOT_CLOCK_HZ: f64 = 7_881_984.0;

/// Dot clock of the NTSC VIC-II: eight pixels per 1,022,727 Hz cycle.
/// Reproduces the published 0.7500.
pub const NTSC_DOT_CLOCK_HZ: f64 = 8_181_816.0;

/// Framebuffer width: 52 of the line's 63 cycles, eight pixels each.
///
/// **Deliberately a little wider than a set's window.** 7.881984 MHz over
/// 52.0 µs is 410 pixels and this holds 416, so about three pixels each side
/// are raster a television hides. The figure is the VIC-II's own cycle
/// numbering rather than a chosen border, which is the trade: the extra costs
/// six pixels and keeps every position in this file expressible as a cycle.
///
/// See `knowledge/decisions/the-framebuffer-is-the-sets-window.md`, which
/// asks that holding more be stated rather than allowed to accumulate.
pub const FB_WIDTH: u32 = VISIBLE_CYCLES as u32 * 8;

/// Framebuffer height: the whole PAL frame, vertical interval included.
///
/// **Deliberately taller than a set's window** — 312 lines against the 288 a
/// television displays, which the #1054 audit reads as 108%. A raster
/// interrupt can change the border colour on any line of the frame, including
/// the ones inside the vertical interval, and holding the whole frame is what
/// lets a capture show that.
pub const FB_HEIGHT: u32 = (PAL_LAST_VISIBLE_LINE - PAL_FIRST_VISIBLE_LINE) as u32;
const DISPLAY_START_LINE: u16 = 0x30;
const DISPLAY_END_LINE: u16 = 0xF8;
const DISPLAY_START_CYCLE: u8 = 16;
const DISPLAY_END_CYCLE: u8 = 56;
const SPRITE_X_TO_FB: i16 = 24;

/// Narrow VIC-visible memory bus.
pub trait VicMemory {
    /// Read a byte from VIC-visible memory using the full 16-bit VIC address.
    fn read_vram(&self, addr: u16) -> u8;

    /// Whether the full 16-bit VIC address reads the character ROM.
    fn is_character_rom(&self, addr: u16) -> bool;

    /// Read a colour RAM nibble at the given 0-1023 offset.
    fn read_colour(&self, offset: u16) -> u8;
}

/// VIC-II model variant.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum VicModel {
    /// PAL 6569: 312 lines, 63 cycles per line.
    #[default]
    Pal6569,
    /// NTSC 6567R8: 263 lines, 65 cycles per line.
    Ntsc6567,
    /// NTSC 6567R56A (early NTSC): 262 lines, 64 cycles per line.
    Ntsc6567R56A,
    /// PAL 8565 (HMOS-II, C64C): the 6569's timing with the grey-dot colour
    /// stage.
    Pal8565,
    /// NTSC 8562 (HMOS-II, C64C): the 6567R8's timing with the grey-dot
    /// colour stage.
    Ntsc8562,
}

impl VicModel {
    /// Total raster lines per frame.
    #[must_use]
    pub const fn lines_per_frame(self) -> u16 {
        match self {
            Self::Pal6569 | Self::Pal8565 => 312,
            Self::Ntsc6567 | Self::Ntsc8562 => 263,
            Self::Ntsc6567R56A => 262,
        }
    }

    /// `phi2` cycles per raster line.
    #[must_use]
    pub const fn cycles_per_line(self) -> u8 {
        match self {
            Self::Pal6569 | Self::Pal8565 => 63,
            Self::Ntsc6567 | Self::Ntsc8562 => 65,
            Self::Ntsc6567R56A => 64,
        }
    }

    /// The model's sprite-region cycle schedule. The c-access/g-access region
    /// and its counter events (UpdateVc cyc 14, UpdateMcBase 16, UpdateRc 58)
    /// are identical across models; only the sprite fetch/DMA region differs,
    /// because the NTSC variants' extra cycles are inserted there.
    const fn sprite_timing(self) -> SpriteTiming {
        match self {
            Self::Pal6569 | Self::Pal8565 => SPRITE_TIMING_PAL,
            Self::Ntsc6567 | Self::Ntsc8562 => SPRITE_TIMING_NTSC,
            Self::Ntsc6567R56A => SPRITE_TIMING_NTSC_R56A,
        }
    }

    /// Whether a colour-register write shows the HMOS-II grey dot.
    ///
    /// Both families resolve dots 1-7 of a cell after the CPU writes of the
    /// two following cycles; they differ on dot 0. The NMOS 6567/6569 resolve
    /// it one cycle earlier, so a dot naming the register just written keeps
    /// the old colour. The HMOS-II 8562/8565 resolve it with the other seven
    /// but show light grey (`$F`) when its source is the register written in
    /// that cycle. VICE x64sc models the split as `color_latency`
    /// (`viciisc/vicii-chip-model.c`), drawn by `draw_colors_6569` and
    /// `draw_colors_8565` (`viciisc/vicii-draw-cycle.c`); the testbench's
    /// `greydot` and `colorsplit` programs carry a reference for each family.
    #[must_use]
    pub const fn has_grey_dot(self) -> bool {
        matches!(self, Self::Pal8565 | Self::Ntsc8562)
    }
}

/// Model-specific sprite cycle schedule, in engine 0-based `raster_cycle`
/// values (VICE's 1-based cycle N maps to engine N, with the line's last cycle
/// relabelled 0). Sourced from VICE `vicii-chip-model.c` `cycle_tab_pal` /
/// `cycle_tab_ntsc`.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
struct SpriteTiming {
    /// Per sprite 0..7: the p-access cycle (pointer + data byte 0) and whether
    /// it fetches for the next raster line (sprites whose p-access sits in the
    /// previous line's tail). The s-access (data bytes 1-2) is the next cycle;
    /// the BA lead-in is the three cycles before the p-access.
    paccess: [(u8, bool); 8],
    /// The two cycles the sprite-DMA check fires (VICE `ChkSprDma`).
    chk_dma: [u8; 2],
    /// Y-expansion flip-flop toggle cycle (VICE `ChkSprExp`).
    chk_exp: u8,
    /// Sprite display-bit latch cycle — `MC = MCBASE` (VICE `ChkSprDisp`).
    chk_disp: u8,
}

/// PAL 6569: 63-cycle line. Sprites 0-2 p-access in the previous line's tail
/// (58/60/62), sprites 3-7 on the current line (1/3/5/7/9).
const SPRITE_TIMING_PAL: SpriteTiming = SpriteTiming {
    paccess: [
        (58, true),
        (60, true),
        (62, true),
        (1, false),
        (3, false),
        (5, false),
        (7, false),
        (9, false),
    ],
    chk_dma: [55, 56],
    chk_exp: 56,
    chk_disp: 58,
};

/// NTSC 6567R8: 65-cycle line. The extra two cycles push the sprite region
/// later — sprites 0-3 p-access in the previous line's tail (59/61/63/0-wrap),
/// sprites 4-7 on the current line (2/4/6/8); DMA/display checks shift by one.
const SPRITE_TIMING_NTSC: SpriteTiming = SpriteTiming {
    paccess: [
        (59, true),
        (61, true),
        (63, true),
        (0, true),
        (2, false),
        (4, false),
        (6, false),
        (8, false),
    ],
    chk_dma: [56, 57],
    chk_exp: 56,
    chk_disp: 59,
};

/// NTSC 6567R56A (early NTSC): 64-cycle line. Sits between PAL and R8 — sprites
/// 3-7 p-access on the current line as PAL (1/3/5/7/9), but sprites 0-2 shift
/// one cycle later than PAL to 59/61/63, and the DMA check is at 56/57 (like
/// R8) while the display latch stays at 58 (like PAL). Sourced from VICE
/// `cycle_tab_ntsc_old`.
const SPRITE_TIMING_NTSC_R56A: SpriteTiming = SpriteTiming {
    paccess: [
        (59, true),
        (61, true),
        (63, true),
        (1, false),
        (3, false),
        (5, false),
        (7, false),
        (9, false),
    ],
    chk_dma: [56, 57],
    chk_exp: 56,
    chk_disp: 58,
};

/// One g-access as the graphics sequencer receives it: the bitmap byte and
/// the video-matrix and colour entries paired with it (VICE's `gbuf`, `vbuf`
/// and `cbuf`).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
struct GraphicsData {
    gbuf: u8,
    vbuf: u8,
    cbuf: u8,
}

/// BMM as the sequencer's pipes hold it. The pipes keep ECM at `$10`, BMM at
/// `$08` and MCM at `$04`, so `vmode | pixel` indexes [`GRAPHICS_COLOURS`].
const VMODE_BMM: u8 = 0x08;

/// A dot's colour selector before the matrix and colour entries resolve it.
#[derive(Clone, Copy)]
enum GraphicsColour {
    /// A colour register, `$D021`-`$D023`.
    Register(u8),
    /// The low nybble of the matrix entry.
    VbufLow,
    /// The high nybble of the matrix entry.
    VbufHigh,
    /// The colour entry.
    Cbuf,
    /// The colour entry's low three bits (multicolour text).
    CbufMulticolour,
    /// `$D021`-`$D024`, chosen by the matrix entry's top two bits (ECM).
    Extended,
    /// Black: the invalid modes.
    None,
}

/// The colour each two-bit pixel selects in each mode, indexed by
/// `ECM | BMM | MCM | pixel` (VICE `colors[]`, `viciisc/vicii-draw-cycle.c`).
/// Hires pixels are 0 or 3; multicolour pixels 0-3. Pixel 2 of a hires dot
/// appears only in the cycle MCM switches on (see [`GraphicsSequencer::draw`]).
const GRAPHICS_COLOURS: [GraphicsColour; 32] = {
    use GraphicsColour::{Cbuf, CbufMulticolour, Extended, None, Register, VbufHigh, VbufLow};
    [
        // ECM=0 BMM=0 MCM=0: standard text.
        Register(0x21),
        Register(0x21),
        Cbuf,
        Cbuf,
        // ECM=0 BMM=0 MCM=1: multicolour text.
        Register(0x21),
        Register(0x22),
        Register(0x23),
        CbufMulticolour,
        // ECM=0 BMM=1 MCM=0: hires bitmap.
        VbufLow,
        VbufLow,
        VbufHigh,
        VbufHigh,
        // ECM=0 BMM=1 MCM=1: multicolour bitmap.
        Register(0x21),
        VbufHigh,
        VbufLow,
        Cbuf,
        // ECM=1 BMM=0 MCM=0: extended-colour text.
        Extended,
        Extended,
        Cbuf,
        Cbuf,
        // The three invalid modes.
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
    ]
};

/// The graphics sequencer: the shift register, the matrix and colour entries
/// it decodes with, and the pipes that carry XSCROLL and the mode bits to it.
///
/// The display mode belongs to the graphics data sequencer, whose heart is
/// an 8-bit shift register reloaded after every g-access, delayed by XSCROLL
/// dots (Bauer, "The MOS 6567/6569 video controller (VIC-II) and its
/// application in the Commodore 64", section 3.7.3). The mode is applied to
/// the bits the register shifts out, not to the g-access, so a mid-line mode
/// change takes effect at a fixed dot of the cycle, whatever the XSCROLL.
/// A 6569R5 capture of the testbench's `modesplit` shows the invalid-mode
/// blocks with straight edges at every XSCROLL. Bauer gives no dot for the
/// change. This follows VICE x64sc's `draw_graphics8`
/// (`viciisc/vicii-draw-cycle.c`), which matches the testbench's 6569 and
/// 8565 `modesplit` references to within one dot at some edges. MCM reaches
/// the colour lookup at dot 4. ECM and BMM rise at dot 4 and fall at dot 6
/// on the NMOS 6567/6569, and arrive after dot 7 on the HMOS-II 8562/8565.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
struct GraphicsSequencer {
    /// The XSCROLL the next cell loads at (VICE `xscroll_pipe`).
    xscroll: u8,
    /// ECM and BMM as the colour lookup sees them (VICE `vmode11_pipe`).
    vmode11: u8,
    /// MCM as the colour lookup sees it (VICE `vmode16_pipe`).
    vmode16: u8,
    /// MCM as the pixel decoder sees it, one stage later (`vmode16_pipe2`).
    vmode16_decode: u8,
    /// The shift register (`gbuf_reg`).
    shift: u8,
    /// Whether the next multicolour dot reads a new bit pair (`gbuf_mc_flop`).
    mc_flop: bool,
    /// The two-bit pixel being shown (`gbuf_pixel_reg`).
    pixel: u8,
    /// The matrix and colour entries loaded with the shift register.
    vbuf: u8,
    cbuf: u8,
}

impl GraphicsSequencer {
    /// Shift out one cycle's eight dots, loading `data` at the current
    /// XSCROLL. `d011` and `d016` are the registers after the CPU access of
    /// this cycle; the pipes hold the previous cycle's. Returns each dot's
    /// colour source and the foreground mask. With `sample_xscroll`, the next
    /// cell's XSCROLL is taken from `d016`; otherwise it keeps this one's.
    fn draw(
        &mut self,
        data: GraphicsData,
        d011: u8,
        d016: u8,
        colour_latency: bool,
        sample_xscroll: bool,
    ) -> ([u8; 8], u8) {
        let mode11 = (d011 & 0x60) >> 2;
        let mut sources = [0; 8];
        let mut fg_mask = 0;
        for dot in 0..8u8 {
            match dot {
                4 => {
                    self.vmode16 = (d016 & 0x10) >> 2;
                    if colour_latency {
                        self.vmode11 |= mode11;
                    }
                }
                6 if colour_latency => self.vmode11 &= mode11,
                7 => {
                    if self.vmode16 != 0 && self.vmode16_decode == 0 {
                        self.mc_flop = false;
                    }
                    self.vmode16_decode = self.vmode16;
                }
                _ => {}
            }
            if dot == self.xscroll {
                self.shift = data.gbuf;
                self.vbuf = data.vbuf;
                self.cbuf = data.cbuf;
                self.mc_flop = true;
            }
            let multicolour = self.vmode11 & VMODE_BMM != 0 || self.cbuf & 0x08 != 0;
            if self.vmode16_decode != 0 {
                if multicolour {
                    if self.mc_flop {
                        self.pixel = self.shift >> 6;
                    }
                } else {
                    self.pixel = if self.shift & 0x80 != 0 { 3 } else { 0 };
                }
            } else {
                // A hires dot reads as pixel 2 where multicolour would
                // apply, so the cycle MCM switches on selects `$D023` for it
                // in multicolour text (VICE's "$d023 glitch").
                let set = if multicolour { 2 } else { 3 };
                self.pixel = if self.shift & 0x80 != 0 { set } else { 0 };
            }
            self.shift <<= 1;
            self.mc_flop = !self.mc_flop;

            let vmode = self.vmode11 | self.vmode16;
            let pixel = self.pixel;
            fg_mask |= ((pixel >> 1) & 1) << dot;
            sources[usize::from(dot)] = match GRAPHICS_COLOURS[usize::from(vmode | pixel)] {
                GraphicsColour::Register(register) => register,
                GraphicsColour::VbufLow => self.vbuf & 0x0F,
                GraphicsColour::VbufHigh => self.vbuf >> 4,
                GraphicsColour::Cbuf => self.cbuf & 0x0F,
                GraphicsColour::CbufMulticolour => self.cbuf & 0x07,
                GraphicsColour::Extended => 0x21 + (self.vbuf >> 6),
                GraphicsColour::None => 0x00,
            };
        }
        if !colour_latency {
            self.vmode11 = mode11;
        }
        if sample_xscroll {
            self.xscroll = d016 & 0x07;
        }
        (sources, fg_mask)
    }
}

/// A cycle's g-access as it waits in the colour stage for the graphics
/// sequencer. See [`Vic::draw_pending_graphics`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct GraphicsInput {
    data: GraphicsData,
    /// Whether this cycle's draw samples the next cell's XSCROLL.
    sample_xscroll: bool,
}

/// A CPU write to a colour register (`$D020`-`$D02E`) made after the most
/// recent tick. The colour stage treats the first dot of the oldest cell
/// specially when it names this register; see [`VicModel::has_grey_dot`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct ColourRegisterWrite {
    /// The register written, as its symbolic source `$20`-`$2E`.
    register: u8,
    /// The register's value before the write.
    previous: u8,
}

/// One rendered cell waiting in the colour stage: its framebuffer offset and
/// the source each dot selected, either a direct colour (`$00`-`$0F`) or a
/// colour register (`$20`-`$2E`). The graphics sequencer draws the cell's
/// g-access, and the sprites are composited over it, as the cell leaves the
/// stage.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct PendingCell {
    fb_offset: usize,
    sources: [Option<u8>; 8],
    graphics: Option<GraphicsInput>,
    /// Each dot's sprite colour source, from this cycle's sprite pixels.
    sprites: [Option<u8>; 8],
    /// The dots whose sprite sits behind foreground graphics (`$D01B`).
    sprite_behind: u8,
}

/// Bounded C-data carry state for a forced badline created at the end of the
/// matrix-fetch window. Hoxs64's measured model propagates selected bits
/// through paired 12-bit colour/screen entries during the next RC-zero line.
#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
struct ForcedBadlineCdataCarry {
    /// Clocks after the invalid c-access. The Hoxs64 merge uses `age - 1` and
    /// remains eligible while that value is below 40.
    age: u8,
    /// Selected bits carried from the preceding merge.
    carry: u16,
}

/// VIC-II chip state.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Vic {
    /// IRQ output pin.
    pub irq: bool,
    /// BA pin, represented as `true` when BA is asserted low.
    ///
    /// BA is the VIC-II's request signal to the CPU: "I need the bus
    /// in a few cycles." On the C64, BA is wired to the 6510's RDY
    /// pin, which stalls *reads* but lets *writes* complete. BA goes
    /// low 3 phi2 cycles before the VIC-II actually needs the bus
    /// (cycle 12 of a badline; the badline DMA itself starts at
    /// cycle 15). That 3-cycle warm-up is the canonical NMOS-6510
    /// pattern.
    ///
    /// See [`Vic::cpu_stalled`] for the AEC-equivalent signal that
    /// fires only when the VIC-II is actually on the bus.
    pub ba_low: bool,
    /// AEC-equivalent: `true` when the CPU is actually off the bus because the
    /// VIC-II has taken it. This becomes true on the fourth consecutive cycle
    /// of aggregate BA-low state and remains true while BA stays low, including
    /// across overlapping badline and sprite requests.
    ///
    /// The machine layer drives `cpu.rdy` from `ba_low` (NMOS-correct), while
    /// this field controls whether a Phi2 matrix access owns the memory bus.
    /// The asymmetry between the two signals is asserted in unit tests; see
    /// `c64-architecture-review.md` Seam 1.
    pub cpu_stalled: bool,
    /// Number of consecutive Phi2 cycles for which aggregate BA has remained
    /// low, saturated at four. The first three cycles are the CPU wind-down
    /// interval; at four the VIC-II owns the bus and AEC is low.
    ba_low_cycles: u8,
    /// Source-resolved copy of the matrix-DMA contribution to the most recent
    /// aggregate BA result.
    badline_ba_low: bool,
    /// Source-resolved copy of the sprite-DMA contribution to the most recent
    /// aggregate BA result.
    sprite_ba_low: bool,
    /// Whether the most recent Phi2 phase attempted a video-matrix c-access.
    /// This remains true for an invalid pre-AEC access; ownership validity is
    /// reported separately by [`Vic::aec_is_low`].
    c_access_active: bool,
    /// A `$D011` write is applied after the VIC phase in the board scheduler.
    /// Retaining its completed CPU phase until the next VIC tick lets
    /// `check_badline` distinguish a dynamically-created late badline from an
    /// ordinary line that was already bad before its DMA window.
    pending_d011_write_cycle: Option<u8>,
    /// Remaining c-accesses in a badline created at the post-VIC far edge
    /// (CPU completion phase 53 or later). `None` leaves ordinary and earlier
    /// forced badlines on their established streaming schedule; `Some(0)`
    /// deliberately remains distinct after the far-edge window is exhausted
    /// so the generic cycle-54 slot cannot reopen it.
    late_badline_fetches_remaining: Option<u8>,
    /// Number of already-pipelined idle cells still presented after a `$D011`
    /// write changes the VIC-II from idle to display state. The first affected
    /// cycle was rendered before the Phi2 transition; these are the two
    /// additional C/V/G cells resident in the output pipeline.
    forced_badline_output_delay: u8,
    /// Bounded age/carry state for the 12-bit C-data merge network triggered
    /// by the sole invalid far-edge c-access. The network remains eligible
    /// through the following RC-zero display window.
    forced_badline_cdata_carry: Option<ForcedBadlineCdataCarry>,

    #[serde(with = "BigArray")]
    regs: [u8; 0x40],
    raster_line: u16,
    raster_cycle: u8,
    raster_compare: u16,
    irq_status: u8,
    irq_enable: u8,
    is_badline: bool,
    den_latch: bool,
    frame_complete: bool,
    framebuffer: Vec<u32>,
    #[serde(skip)]
    signal_codes: Vec<u16>,
    #[serde(with = "BigArray")]
    screen_row: [u8; 40],
    #[serde(with = "BigArray")]
    colour_row: [u8; 40],
    vic_bank: u8,
    /// Draw-stage sprite sequencer (VICE shift-register pixel pipeline). It is
    /// the sole sprite render path. Its shift registers and per-pixel flops
    /// persist across cycles, so snapshots preserve it at arbitrary phases.
    sprite_sequencer: SpriteSequencer,
    /// Sprite fetch chain (MC/MCBASE/exp-flop + crunch) and its MC-addressed
    /// data, feeding the sequencer continuously (VICE model): the chain sets
    /// display bits at cyc 58 (→ `set_pending`) and loads data at the s-access
    /// (→ `load_data`). Used only on the sequencer path. MC/MCBASE and fetched
    /// data are live hardware state and therefore part of a snapshot.
    chain: SpriteFetchChain,
    chain_data: [[u8; 3]; 8],
    chain_fetch_base: [u16; 8],
    /// This cycle's 8 raw sprite pixels (pre-foreground-priority), produced by
    /// the per-cycle draw pass and composited by `render_pixels`.
    sprite_cycle_px: [Option<SpritePixel>; 8],
    /// This cycle's 8 sprite coverage masks (which sprites have a pixel), for
    /// collision detection in the composite.
    sprite_cycle_cov: [u8; 8],
    /// This cycle's graphics foreground mask (8 bits), latched by
    /// `render_pixels` for the collision pass. Zero off the display window, so
    /// sprite-background collisions only register over real foreground while
    /// sprite-sprite collisions still register everywhere.
    gfx_fg_mask: u8,
    sprite_sprite_collision: u8,
    sprite_bg_collision: u8,
    sprite_sprite_irq_latched: bool,
    sprite_bg_irq_latched: bool,
    /// The graphics sequencer, as of the last cell to leave the colour
    /// stage.
    sequencer: GraphicsSequencer,
    /// The matrix and colour entries of the last g-access in the display
    /// window, which the sequencer keeps loading outside it.
    last_matrix_entries: (u8, u8),
    /// `$D011` as it stood for the previous g-access (VICE `reg11_delay`).
    /// The g-access reads its mode bits through it; see
    /// [`Vic::fetch_display_graphics`].
    d011_delayed: u8,
    lines_per_frame: u16,
    cycles_per_line: u8,
    /// Model-specific sprite-region cycle schedule (PAL 6569 vs NTSC 6567).
    timing: SpriteTiming,
    first_visible_line: u16,
    last_visible_line: u16,
    lp_triggered: bool,
    /// Light-pen input level: `true` while held low.
    lp_line_low: bool,
    last_bus_data: u8,
    /// Vertical border flip-flop. Set at the last raster line of the
    /// display window, cleared at the first (DEN=1 required). Gates
    /// whether the main FF can be cleared — when vert FF is set, the
    /// main FF stays set, producing solid border for the whole line.
    border_vert_ff: bool,
    /// Main (horizontal) border flip-flop. Set at right edge of display,
    /// cleared at left edge (only if vert FF is clear). When set, the
    /// current cycle paints border colour.
    border_main_ff: bool,

    // --- Video-counter chain (VC/VCBASE/RC/VMLI) ---
    //
    // Live VIC-II addressing chain. VC drives graphics and matrix addressing;
    // VMLI selects the paired screen/colour row entry consumed by the display
    // pipeline and filled by c-access. The Phi1/Phi2 split preserves the
    // delayed display-state transition of a forced late badline.
    /// Video counter (10-bit) — the live video-matrix offset.
    vc: u16,
    /// Video counter base (10-bit) — latched from VC at each row end (RC==7).
    vcbase: u16,
    /// Row counter (3-bit) — the character sub-row (0-7) being displayed.
    rc: u8,
    /// Video matrix line index (0-39) — index into the matrix line buffer.
    vmli: u8,
    /// Idle state — gates the g-access VC/VMLI advance. Cleared by a badline,
    /// set when RC passes 7. Starts idle (top border before the first row).
    idle_state: bool,

    /// VICE's main border flip-flop, set and cleared at its own check cycles
    /// (`check_hborder`, `viciisc/vicii-cycle.c`).
    display_border: bool,
    /// `display_border` after each of the previous two ticks, oldest first:
    /// the states VICE's `draw_border8` reads for the oldest pending cell.
    display_border_history: [bool; 2],
    /// Colour stage: the cells rendered by the previous two ticks, oldest
    /// first, waiting for their colour registers to be resolved. See
    /// [`Vic::resolve_oldest_cell`].
    colour_stage: [Option<PendingCell>; 2],
    /// The colour-register write made since the last tick.
    colour_write: Option<ColourRegisterWrite>,
    /// The chip revision. It selects the first-dot rule of the colour stage
    /// ([`VicModel::has_grey_dot`]); the timing it implies is held in the
    /// fields above.
    model: VicModel,
}

impl Vic {
    /// Construct a VIC-II for the given hardware model.
    #[must_use]
    pub fn new(model: VicModel) -> Self {
        let (first_vis, last_vis) = match model {
            VicModel::Pal6569 | VicModel::Pal8565 => {
                (PAL_FIRST_VISIBLE_LINE, PAL_LAST_VISIBLE_LINE)
            }
            // The NTSC variants share the visible-line window; R56A has one
            // fewer total line but the same displayed region.
            VicModel::Ntsc6567 | VicModel::Ntsc6567R56A | VicModel::Ntsc8562 => {
                (NTSC_FIRST_VISIBLE_LINE, NTSC_LAST_VISIBLE_LINE)
            }
        };
        let visible_lines = u32::from(last_vis - first_vis);
        let fb_size = FB_WIDTH as usize * visible_lines as usize;

        Self {
            irq: false,
            ba_low: false,
            cpu_stalled: false,
            ba_low_cycles: 0,
            badline_ba_low: false,
            sprite_ba_low: false,
            c_access_active: false,
            pending_d011_write_cycle: None,
            late_badline_fetches_remaining: None,
            forced_badline_output_delay: 0,
            forced_badline_cdata_carry: None,
            regs: [0; 0x40],
            raster_line: 0,
            raster_cycle: 0,
            raster_compare: 0,
            irq_status: 0,
            irq_enable: 0,
            is_badline: false,
            den_latch: false,
            frame_complete: false,
            framebuffer: vec![0xFF00_0000; fb_size],
            signal_codes: vec![0; fb_size],
            screen_row: [0; 40],
            colour_row: [0; 40],
            vic_bank: 0,
            sprite_sequencer: SpriteSequencer::new(),
            chain: SpriteFetchChain::new(),
            chain_data: [[0; 3]; 8],
            chain_fetch_base: [0; 8],
            sprite_cycle_px: [None; 8],
            sprite_cycle_cov: [0; 8],
            gfx_fg_mask: 0,
            sprite_sprite_collision: 0,
            sprite_bg_collision: 0,
            sprite_sprite_irq_latched: false,
            sprite_bg_irq_latched: false,
            sequencer: GraphicsSequencer::default(),
            last_matrix_entries: (0, 0),
            d011_delayed: 0,
            lines_per_frame: model.lines_per_frame(),
            cycles_per_line: model.cycles_per_line(),
            timing: model.sprite_timing(),
            first_visible_line: first_vis,
            last_visible_line: last_vis,
            lp_triggered: false,
            lp_line_low: false,
            last_bus_data: 0,
            border_vert_ff: true,
            border_main_ff: true,
            vc: 0,
            vcbase: 0,
            rc: 0,
            vmli: 0,
            idle_state: true,
            display_border: true,
            display_border_history: [true; 2],
            colour_stage: [None; 2],
            colour_write: None,
            model,
        }
    }

    /// The chip revision this VIC-II models.
    #[must_use]
    pub const fn model(&self) -> VicModel {
        self.model
    }

    /// Tick the VIC-II for one `phi2` cycle.
    pub fn tick(&mut self, memory: &dyn VicMemory, phi2_bus: VicPhi2Bus) -> bool {
        // The display/g-access phase sees the state entering this cycle. A
        // forced badline created after cycle 15 does not leave idle until the
        // cycle-16 Phi2 phase, so its first active display access is cycle 17.
        let display_active_at_phi1 = !self.idle_state;
        // The far-edge transition leaves two idle-looking cells in the output
        // pipe, but only the first following G-access remains idle. The second
        // hidden cell is backed by an active access and advances VC/VMLI.
        let forced_g_access_delayed = self.forced_badline_output_delay == 2;
        self.resolve_forced_badline_cdata_carry(display_active_at_phi1);

        // Advance the MC/MCBASE/exp-flop chain + its MC-addressed fetch (chain
        // stage), then run the draw stage for this cycle's 8 pixels. The draw
        // runs every cycle (not just visible) so the shift register + DMA-halt
        // housekeeping stay correct through the border.
        self.advance_sprite_chain(memory);
        self.run_sprite_draw_cycle();

        self.update_border_flip_flops();
        self.update_display_border();
        self.resolve_oldest_cell();
        let rendered = self.render_pixels(memory, display_active_at_phi1);
        self.colour_stage = [self.colour_stage[1], rendered];
        // The write has reached the cell that resolves its first dot early;
        // the CPU access after this tick may record the next.
        self.colour_write = None;
        self.accumulate_sprite_collisions();
        self.advance_video_counters_after_g_access(display_active_at_phi1, forced_g_access_delayed);
        self.forced_badline_output_delay = self.forced_badline_output_delay.saturating_sub(1);
        self.check_badline();
        self.apply_phi2_video_counter_events();

        self.badline_ba_low = self.badline_ba_low();
        self.sprite_ba_low = self.sprite_ba_low();
        self.ba_low = self.badline_ba_low || self.sprite_ba_low;
        self.ba_low_cycles = if self.ba_low {
            self.ba_low_cycles.saturating_add(1).min(4)
        } else {
            0
        };
        self.cpu_stalled = self.ba_low_cycles == 4;

        // Stream the video-matrix c-access: one read per Phi2 cycle of a
        // badline (cycles 15-54), into the matrix line buffer indexed by VMLI
        // and addressed by VC. The per-cycle replacement for the archive's
        // batched 40-read row fetch preserves ordinary row bytes while also
        // representing the shorter fetch sequence of a forced late badline.
        // Age an existing forced-badline carry before this cycle's c-access.
        // A state armed by the access below therefore remains at age zero
        // until the following clock, matching the Hoxs64 origin convention.
        self.age_forced_badline_cdata_carry();
        self.c_access_active = self.badline_c_access_active();
        if self.c_access_active {
            self.c_access(memory, phi2_bus.cpu_data);
            if let Some(remaining) = &mut self.late_badline_fetches_remaining {
                *remaining = remaining.saturating_sub(1);
            }
        }
        self.d011_delayed = self.regs[0x11];
        self.raster_cycle += 1;
        if self.raster_cycle >= self.cycles_per_line {
            self.raster_cycle = 0;
            self.raster_line += 1;
            self.late_badline_fetches_remaining = None;

            if self.raster_line >= self.lines_per_frame {
                self.raster_line = 0;
                self.frame_complete = true;
                self.den_latch = false;
                self.lp_triggered = false;
                // A light pen still held low retriggers as the frame starts.
                if self.lp_line_low {
                    self.latch_light_pen(true);
                }
            }
        }

        // The comparator sees the line the CPU sees, so the IRQ asserts as
        // that line begins: on the Phi2 half of cycle 1, or cycle 2 on line
        // 0. `raster_cycle` has already advanced past the cycle just run, so
        // the CPU access that follows this tick is the first to see it.
        if self.raster_cycle == self.cpu_line_edge_cycle() + 1
            && self.raster_line == self.raster_compare
        {
            self.irq_status |= 0x01;
        }

        self.irq = (self.irq_status & self.irq_enable & 0x0F) != 0;
        self.cpu_stalled
    }

    fn vram_addr(&self, bank_offset: u16) -> u16 {
        u16::from(self.vic_bank) * 0x4000 + (bank_offset & 0x3FFF)
    }

    fn check_badline(&mut self) {
        let was_badline = self.is_badline;
        let den = self.regs[0x11] & 0x10 != 0;
        let yscroll = u16::from(self.regs[0x11] & 0x07);
        // The badline comparator reads the raster counter, which moves on to
        // the new line at the line edge, not at engine cycle 0.
        let line = self.counter_line();

        if line == DISPLAY_START_LINE && den {
            self.den_latch = true;
        }

        self.is_badline = self.den_latch
            && (DISPLAY_START_LINE..DISPLAY_END_LINE).contains(&line)
            && (line & 7) == yscroll;

        if let Some(write_cycle) = self.pending_d011_write_cycle.take() {
            if !was_badline && self.is_badline {
                // A write in cycle 54 lands before that cycle's Phi2 matrix
                // fetch, so it keeps that one access, which this engine makes
                // on the following tick. A write in cycle 55 or later keeps
                // none.
                self.late_badline_fetches_remaining =
                    (write_cycle >= 54).then_some(55u8.saturating_sub(write_cycle));
                if self.late_badline_fetches_remaining.is_some() {
                    // At the post-VIC far edge, Phi1 and the current draw have
                    // already observed idle state. The two C/V/G cells behind
                    // that fetch remain in the output pipeline after the Phi2
                    // badline transition. Earlier forced badlines retain the
                    // separately evidenced colour-fetch schedule.
                    self.forced_badline_output_delay = 2;
                }
            } else if was_badline && !self.is_badline {
                self.late_badline_fetches_remaining = None;
            }
        }
    }

    /// Advance VC/VMLI after this cycle's Phi1 display g-access.
    ///
    /// The entering idle/display state is captured before the cycle begins.
    /// This matters when a D011 write creates a late badline: cycle 16 remains
    /// an idle g-access even though Phi2 enables display and performs c-access
    /// zero. Cycle 17 is then the first g-access that advances the counters.
    fn advance_video_counters_after_g_access(
        &mut self,
        display_active_at_phi1: bool,
        forced_output_delayed: bool,
    ) {
        let c = self.raster_cycle;

        if (16..=55).contains(&c) && display_active_at_phi1 && !forced_output_delayed {
            self.vc = (self.vc + 1) & 0x03FF;
            if self.vmli < 40 {
                self.vmli += 1;
            }
        }
    }

    /// Apply the Phi2 events in the VC/VCBASE/RC/VMLI chain.
    ///
    /// Ported from VICE (`vicii-cycle.c` start-of-frame, UpdateVc, UpdateRc
    /// and badline idle-state changes). This runs after `check_badline`, so a
    /// register write observed on this cycle may change the Phi2 badline state
    /// without retroactively changing the Phi1 g-access above.
    fn apply_phi2_video_counter_events(&mut self) {
        let c = self.raster_cycle;

        // Start of frame: VC and VCBASE reset (VICE start_of_frame).
        if self.raster_line == 0 && c == 0 {
            self.vc = 0;
            self.vcbase = 0;
        }

        // A badline takes the chip out of idle (VICE check_badline).
        if self.is_badline {
            self.idle_state = false;
        }

        // UpdateVc — canonical cycle 14: reload VC from VCBASE, clear VMLI,
        // and (on a badline) reset the row counter.
        if c == 14 {
            self.vc = self.vcbase;
            self.vmli = 0;
            if self.is_badline {
                self.rc = 0;
            }
        }

        // UpdateRc — canonical cycle 58: at the end of an 8-row block latch
        // VCBASE and go idle; otherwise step the row counter.
        if c == 58 {
            if self.rc == 7 {
                self.idle_state = true;
                self.vcbase = self.vc;
            }
            if !self.idle_state || self.is_badline {
                self.rc = (self.rc + 1) & 0x07;
                self.idle_state = false;
            }
        }
    }

    /// Live video counter (VC).
    #[must_use]
    pub const fn vc(&self) -> u16 {
        self.vc
    }

    /// Live video counter base (VCBASE).
    #[must_use]
    pub const fn vcbase(&self) -> u16 {
        self.vcbase
    }

    /// Live row counter (RC), 0-7.
    #[must_use]
    pub const fn rc(&self) -> u8 {
        self.rc
    }

    /// Live video matrix line index (VMLI), 0-40.
    #[must_use]
    pub const fn vmli(&self) -> u8 {
        self.vmli
    }

    /// Update border FFs per Bauer's vic-ii.txt rules.
    ///
    /// **Vertical FF** (checked at line boundaries, i.e. cycle 0):
    /// - SET at last display line: 247 (RSEL=0) or 251 (RSEL=1).
    /// - CLEAR at first display line: 55 (RSEL=0) or 51 (RSEL=1), only
    ///   when DEN=1 at that moment.
    ///
    /// **Main FF** (checked every cycle):
    /// - SET at right edge cycle: 56 (CSEL=1) or 55 (CSEL=0).
    /// - CLEAR at left edge cycle: 16 (CSEL=1) or 17 (CSEL=0), only
    ///   when the vertical FF is clear.
    ///
    /// RSEL and CSEL are sampled at the moment each transition fires,
    /// enabling the classic "open the border" trick: software flicks
    /// RSEL/CSEL after the vertical FF would set, suppressing the
    /// transition and leaving the border FF clear.
    fn update_border_flip_flops(&mut self) {
        let rsel = self.regs[0x11] & 0x08 != 0;
        let den = self.regs[0x11] & 0x10 != 0;
        let csel = self.regs[0x16] & 0x08 != 0;

        // Vertical FF transitions fire as the raster counter reaches the line.
        if self.raster_cycle == self.cpu_line_edge_cycle() {
            let last_display = if rsel { 251u16 } else { 247u16 };
            let first_display = if rsel { 51u16 } else { 55u16 };
            if self.raster_line == last_display {
                self.border_vert_ff = true;
            }
            if self.raster_line == first_display && den {
                self.border_vert_ff = false;
            }
        }

        // Main FF transitions fire on per-cycle boundaries.
        let left_edge = if csel { 16u8 } else { 17u8 };
        let right_edge = if csel { 56u8 } else { 55u8 };
        if self.raster_cycle == right_edge {
            self.border_main_ff = true;
        }
        if self.raster_cycle == left_edge && !self.border_vert_ff {
            self.border_main_ff = false;
        }
    }

    /// Single video-matrix c-access for the current cycle: read the screen
    /// code and colour nibble at VC into the matrix line buffer at VMLI.
    ///
    /// Streamed one-per-cycle across a badline's cycles 15-54 (replacing the
    /// archive's batched 40-read row fetch). The screen address is
    /// `screen_base + VC`. VMLI tracks the paired display-buffer entry. On an
    /// ordinary badline this produces the familiar 40 linear cells. During a
    /// forced late badline, attempted accesses before AEC falls store `$FF`
    /// plus the CPU-side low nibble without touching VIC memory.
    fn c_access(&mut self, memory: &dyn VicMemory, cpu_data: u8) {
        let idx = self.vmli as usize;
        if idx >= self.screen_row.len() {
            return;
        }
        if !self.cpu_stalled {
            if self.late_badline_fetches_remaining == Some(1) {
                self.forced_badline_cdata_carry =
                    Some(ForcedBadlineCdataCarry { age: 0, carry: 0 });
            }
            self.screen_row[idx] = 0xFF;
            self.colour_row[idx] = cpu_data & 0x0F;
            // This internal disconnected-matrix value does not update the
            // simplified CPU-visible open-bus latch. That latch needs its own
            // evidence contract before invalid Phi2 activity can change it.
            return;
        }
        let addr = self.vram_addr(self.screen_base() + self.vc);
        let byte = memory.read_vram(addr);
        self.screen_row[idx] = byte;
        self.last_bus_data = byte;
        self.colour_row[idx] = memory.read_colour(self.vc);
    }

    /// Apply Hoxs64's bounded 12-bit forced-badline C-data carry network.
    ///
    /// Each matrix entry is packed as colour nibble + screen byte. During the
    /// next non-bad RC-zero line, the live VMLI entry and an age-derived entry
    /// are merged with selected bits from a third entry. Both destinations are
    /// written, and the selected bits carry into the following g-access.
    fn resolve_forced_badline_cdata_carry(&mut self, display_active_at_phi1: bool) {
        let Some(state) = self.forced_badline_cdata_carry else {
            return;
        };
        let Some(elapsed) = state.age.checked_sub(1) else {
            return;
        };
        if elapsed >= 40
            || !(DISPLAY_START_CYCLE..=55).contains(&self.raster_cycle)
            || !display_active_at_phi1
            || self.is_badline
            || self.rc != 0
            || self.forced_badline_output_delay == 2
        {
            return;
        }

        let i1 = usize::from(self.vmli);
        if i1 >= self.screen_row.len() {
            return;
        }
        let i2_unwrapped = usize::from(elapsed);
        let gap = i2_unwrapped.wrapping_sub(i1);
        if gap == 0 {
            return;
        }
        let i0 = (i2_unwrapped.wrapping_sub(1) % gap) % self.screen_row.len();
        let i2 = i2_unwrapped % self.screen_row.len();
        let char0 = self.packed_cdata(i0);
        let char1 = self.packed_cdata(i1);
        let char2 = self.packed_cdata(i2);
        let carry_source = if (self.raster_cycle + 1) & 3 == 0 {
            char0
        } else {
            state.carry | char0
        };
        let new_carry = 0x08A6 & carry_source;
        let merged = (((new_carry | (char2 & 0x013F)) & (char1 | char2))
            | ((!new_carry & 0x0FFF) & (char1 & char2)))
            & 0x0FFF;

        self.set_packed_cdata(i1, merged);
        self.set_packed_cdata(i2, merged);
        if let Some(carry) = &mut self.forced_badline_cdata_carry {
            carry.carry = new_carry;
        }
    }

    fn age_forced_badline_cdata_carry(&mut self) {
        let Some(carry) = &mut self.forced_badline_cdata_carry else {
            return;
        };
        carry.age = carry.age.saturating_add(1);
        if carry.age > 40 {
            self.forced_badline_cdata_carry = None;
        }
    }

    fn packed_cdata(&self, index: usize) -> u16 {
        u16::from(self.screen_row[index]) | (u16::from(self.colour_row[index] & 0x0F) << 8)
    }

    fn set_packed_cdata(&mut self, index: usize, value: u16) {
        let value = value & 0x0FFF;
        self.screen_row[index] = value as u8;
        self.colour_row[index] = (value >> 8) as u8;
    }

    /// The sprite whose p-access (pointer + data byte 0) falls on this cycle,
    /// and whether it targets the next line, per the model's sprite schedule
    /// (`SpriteTiming::paccess`, VICE `cycle_tab_*` SprPtr/SprDma0). The chain
    /// fetch (`chain_paccess`/`chain_saccess`) and the draw stage both key off
    /// this. PAL: sprites 0-2 fetch in the previous line's tail (58/60/62) for
    /// the next line, 3-7 on the current line (1/3/5/7/9). NTSC's two extra
    /// cycles shift this (see `SPRITE_TIMING_NTSC`).
    fn sprite_paccess_cycle(&self, cycle: u8) -> Option<(usize, bool)> {
        self.timing
            .paccess
            .iter()
            .position(|&(c, _)| c == cycle)
            .map(|i| (i, self.timing.paccess[i].1))
    }

    /// The sprite whose s-access (data bytes 1 and 2) falls on this cycle. The
    /// s-access is always the cycle after the sprite's p-access.
    fn sprite_saccess_cycle(&self, cycle: u8) -> Option<usize> {
        let cpl = self.cycles_per_line;
        self.timing
            .paccess
            .iter()
            .position(|&(c, _)| (c + 1) % cpl == cycle)
    }

    fn render_pixels(
        &mut self,
        memory: &dyn VicMemory,
        display_active_at_phi1: bool,
    ) -> Option<PendingCell> {
        // Cleared every cycle so the collision pass sees no foreground off the
        // display window (borders, retrace); render_pixels re-latches it below
        // only where graphics data is actually shifted out.
        self.gfx_fg_mask = 0;
        if self.raster_line < self.first_visible_line || self.raster_line >= self.last_visible_line
        {
            return None;
        }
        if self.raster_cycle < FIRST_VISIBLE_CYCLE || self.raster_cycle >= LAST_VISIBLE_CYCLE {
            return None;
        }

        let fb_y = (self.raster_line - self.first_visible_line) as usize;
        let fb_x = (self.raster_cycle - FIRST_VISIBLE_CYCLE) as usize * 8;
        let fb_offset = fb_y * FB_WIDTH as usize + fb_x;
        // A cell the sequencer does not draw (a g-access past column 39)
        // shows `$D021`.
        let output_sources = [Some(0x21); 8];
        let in_horizontal_display =
            (DISPLAY_START_CYCLE..DISPLAY_END_CYCLE).contains(&self.raster_cycle);
        let display_pipeline_visible = !self.border_vert_ff && in_horizontal_display;

        let data = if display_pipeline_visible {
            let data = if display_active_at_phi1 && self.forced_badline_output_delay == 0 {
                let col = self.vmli as usize;
                (col < 40).then(|| self.fetch_display_graphics(col, memory))
            } else {
                Some(self.fetch_idle_graphics(memory))
            };
            if let Some(data) = data {
                self.last_matrix_entries = (data.vbuf, data.cbuf);
            }
            data
        } else {
            // Beside the fetch window and under the vertical border the
            // sequencer keeps loading, with zero graphics and the matrix and
            // colour entries of the last g-access: Bauer's "last current
            // background color" (section 3.7.3). VICE updates `vbuf_pipe0_reg`
            // and `cbuf_pipe0_reg` only in the window (`draw_graphics8`).
            let (vbuf, cbuf) = self.last_matrix_entries;
            Some(GraphicsData {
                gbuf: 0,
                vbuf,
                cbuf,
            })
        };
        let graphics = data.map(|data| GraphicsInput {
            data,
            // Each draw samples the next cell's XSCROLL. VICE samples it
            // only as it admits a g-access to its pipe, two cells on, with
            // the vertical border off: from the draw two cells before the
            // window to column 37's. Column 39 keeps column 38's XSCROLL.
            sample_xscroll: !self.border_vert_ff
                && (DISPLAY_START_CYCLE - 2..DISPLAY_END_CYCLE - 2).contains(&self.raster_cycle),
        });

        // The sequencer draws this cell once the CPU accesses of this cycle
        // and the next have set the mode bits it reads. Collisions happen
        // now, so they use the foreground the cell would have if neither
        // access changed `$D011` or `$D016`.
        let mut fg_mask = match graphics {
            Some(input) => {
                let mut sequencer = self.sequencer;
                if let Some(previous) = self.colour_stage[1].and_then(|cell| cell.graphics) {
                    self.draw_graphics_with(&mut sequencer, previous);
                }
                self.draw_graphics_with(&mut sequencer, input).1
            }
            None => 0,
        };

        // Sprites sit above the graphics, subject to `$D01B`; the colour
        // stage composites them once the graphics are drawn. The border is
        // painted over both there too, where the VICE border phase is known
        // (see `apply_border`).
        let priority = self.regs[0x1B];
        let mut sprites = [None; 8];
        let mut sprite_behind = 0;
        for (px, sprite) in sprites.iter_mut().enumerate() {
            let Some(sp) = self.sprite_cycle_px[px] else {
                continue;
            };
            let i = sp.sprite as usize;
            *sprite = Some(match sp.selector {
                1 => 0x25,
                3 => 0x26,
                _ => 0x27 + i as u8,
            });
            if priority & (1 << i) != 0 {
                sprite_behind |= 1 << px;
            }
        }

        // Latch this cycle's foreground mask for the every-cycle collision
        // pass. No foreground collides under the main border flip-flop. The
        // collision accumulation itself lives in `accumulate_sprite_collisions`
        // (called from `tick`) so it runs in the border too.
        if self.border_main_ff {
            fg_mask = 0;
        }
        self.gfx_fg_mask = fg_mask;

        Some(PendingCell {
            fb_offset,
            sources: output_sources,
            graphics,
            sprites,
            sprite_behind,
        })
    }

    /// Draw one cycle of `input` on `sequencer`, with the mode registers as
    /// they stand. Returns the dots' colour sources and the foreground mask.
    fn draw_graphics_with(
        &self,
        sequencer: &mut GraphicsSequencer,
        input: GraphicsInput,
    ) -> ([u8; 8], u8) {
        sequencer.draw(
            input.data,
            self.regs[0x11],
            self.regs[0x16],
            !self.model.has_grey_dot(),
            input.sample_xscroll,
        )
    }

    /// Draw the graphics of the cell leaving the colour stage and composite
    /// its sprites.
    ///
    /// The cell was rendered two ticks ago, so the registers now hold the CPU
    /// writes of its own cycle and the next. VICE x64sc draws a cell from the
    /// g-access two cycles back: XSCROLL and the mode bits for dots 0-3 were
    /// sampled after the CPU access of the cell's own cycle, and those for
    /// dots 4-7 come after the next (`draw_graphics8` in
    /// `viciisc/vicii-draw-cycle.c`). The sequencer's pipes carry the first
    /// from the previous cell's draw; this draw reads the second.
    fn draw_pending_graphics(&mut self, cell: &mut PendingCell) {
        let mut fg_mask = 0;
        if let Some(input) = cell.graphics {
            let mut sequencer = self.sequencer;
            let (sources, fg) = self.draw_graphics_with(&mut sequencer, input);
            self.sequencer = sequencer;
            cell.sources = sources.map(Some);
            fg_mask = fg;
        }
        for (px, output) in cell.sources.iter_mut().enumerate() {
            let Some(sprite) = cell.sprites[px] else {
                continue;
            };
            if (cell.sprite_behind & fg_mask) >> px & 1 == 0 {
                *output = Some(sprite);
            }
        }
    }

    /// Run VICE's main border checks (`check_hborder`): the left edge in cycle
    /// 17 (40 columns) or 18 (38 columns), the right edge in cycle 57 or 56.
    /// They run one cycle after the flip-flop the sequencer uses, and VICE
    /// draws a cell one cycle after its checks, so a CPU write in the cycle
    /// before a check still decides it: the side-border opening tricks.
    fn update_display_border(&mut self) {
        let csel = self.regs[0x16] & 0x08 != 0;
        let c = self.raster_cycle;
        let (left, right) = if csel { (17, 57) } else { (18, 56) };
        if c == left && !self.border_vert_ff {
            self.display_border = false;
        }
        if c == right {
            self.display_border = true;
        }
        self.display_border_history = [self.display_border_history[1], self.display_border];
    }

    /// Paint the border over a pending cell as VICE's `draw_border8` does:
    /// the whole cell while the border was already on, or, with 38 columns,
    /// dots 0-6 from the earlier state and dot 7 from the later one.
    fn apply_border(&self, sources: &mut [Option<u8>; 8]) {
        let [earlier, later] = self.display_border_history;
        let csel = self.regs[0x16] & 0x08 != 0;
        let border = Some(0x20);
        if earlier && later || (csel && earlier) {
            sources.fill(border);
        } else if !csel {
            if earlier {
                sources[..7].fill(border);
            }
            if later {
                sources[7] = border;
            }
        }
    }

    /// Resolve both cells still waiting in the colour stage.
    fn flush_colour_stage(&mut self) {
        self.resolve_oldest_cell();
        self.colour_stage = [self.colour_stage[1], None];
        self.resolve_oldest_cell();
    }

    /// Resolve the cell rendered two ticks ago into the framebuffer.
    ///
    /// The VIC-II resolves a dot's colour register well after the sequencer
    /// has chosen it. VICE x64sc draws a cell one cycle after the engine
    /// renders it (its border checks, `ChkBrdL1` at cycle 17 and `ChkBrdR1`
    /// at 57, land one cycle later through `draw_border8`'s `border_state`
    /// lag) and resolves dots 1-7 in the cycle after that, so they see the
    /// CPU writes of both following cycles. That is now: this tick has not
    /// run its CPU access yet, so the registers hold every write up to the
    /// previous cycle. Dot 0 differs by chip when it names the register
    /// written in the previous cycle ([`VicModel::has_grey_dot`]). The NMOS
    /// 6567/6569 resolve it one cycle earlier (`draw_colors_6569` in
    /// `viciisc/vicii-draw-cycle.c`), so it still shows the old value. The
    /// HMOS-II 8562/8565 show light grey there (`draw_colors_8565`).
    fn resolve_oldest_cell(&mut self) {
        let Some(mut cell) = self.colour_stage[0].take() else {
            return;
        };
        self.draw_pending_graphics(&mut cell);
        self.apply_border(&mut cell.sources);
        if self.signal_codes.len() != self.framebuffer.len() {
            self.rebuild_signal_codes();
        }
        for (px, source) in cell.sources.into_iter().enumerate() {
            let Some(source) = source else {
                continue;
            };
            let colour_index = match self.colour_write {
                Some(write) if px == 0 && write.register == source => {
                    if self.model.has_grey_dot() {
                        0x0F
                    } else {
                        write.previous & 0x0F
                    }
                }
                _ => self.resolve_colour_index(source),
            };
            if let Some(pixel) = self.framebuffer.get_mut(cell.fb_offset + px) {
                *pixel = PALETTE[usize::from(colour_index)];
                self.signal_codes[cell.fb_offset + px] = u16::from(colour_index);
            }
        }
    }

    /// Resolve one direct colour index or symbolic `$D020`-`$D02E` source at
    /// the final composite stage.
    fn resolve_colour_index(&self, source: u8) -> u8 {
        (if (0x20..=0x2E).contains(&source) {
            self.regs[usize::from(source)]
        } else {
            source
        }) & 0x0F
    }

    /// The g-access of the idle display state.
    ///
    /// The VIC-II does not stop its g-access window when `idle_state` is set.
    /// It reads the bank's ghost byte (`$3FFF`, or `$39FF` with ECM enabled)
    /// and presents zero for the paired video-matrix and colour entries. This
    /// normally remains hidden by the border, but vertical/side-border effects
    /// expose it. VICE models the same split in `vicii_fetch_idle_gfx` and the
    /// idle branch of `vicii_draw_cycle`. As in [`Vic::fetch_display_graphics`],
    /// the 8562/8565 read ECM a cycle late.
    fn fetch_idle_graphics(&self, memory: &dyn VicMemory) -> GraphicsData {
        let d011 = if self.model.has_grey_dot() {
            self.d011_delayed
        } else {
            self.regs[0x11]
        };
        let idle_addr = if d011 & 0x40 != 0 { 0x39FF } else { 0x3FFF };
        GraphicsData {
            gbuf: memory.read_vram(self.vram_addr(idle_addr)),
            vbuf: 0,
            cbuf: 0,
        }
    }

    /// The g-access address, within the bank, in the mode `d011` selects for
    /// matrix entry `vbuf` (VICE `g_fetch_addr`, `viciisc/vicii-fetch.c`).
    /// Bitmap modes read `(VC << 3) | RC` from the bitmap base and text modes
    /// the entry's character from the character base. ECM holds address
    /// lines 9 and 10 low (Bauer, section 3.7.3). The invalid modes fetch
    /// too; they only show black.
    fn graphics_fetch_addr(&self, d011: u8, vbuf: u8) -> u16 {
        let addr = if d011 & 0x20 != 0 {
            self.bitmap_base() + self.vc * 8 + u16::from(self.rc)
        } else {
            self.char_base() + u16::from(vbuf) * 8 + u16::from(self.rc)
        };
        if d011 & 0x40 != 0 {
            addr & 0x39FF
        } else {
            addr
        }
    }

    /// The g-access of display column `col`.
    ///
    /// The address generator reads some mode bits a cycle late, as VICE
    /// `vicii_fetch_graphics` models. The HMOS-II 8562/8565 address with the
    /// `$D011` of the previous g-access. The NMOS 6567/6569 see ECM and a
    /// rising BMM at once, but a falling BMM a cycle late. When a BMM change
    /// turns a RAM fetch into a character-ROM fetch, the low address byte
    /// comes from the old address and the rest from the new one. Bauer does not cover
    /// either. The testbench's `modesplit` changes BMM and ECM in mid-line,
    /// and its 6569 and 8565 references show the late cell; VICE matches
    /// them there.
    fn fetch_display_graphics(&self, col: usize, memory: &dyn VicMemory) -> GraphicsData {
        let vbuf = self.screen_row[col];
        let cbuf = self.colour_row[col] & 0x0F;
        let now = self.regs[0x11];
        let delayed = self.d011_delayed;
        let addr = if self.model.has_grey_dot() {
            self.graphics_fetch_addr(delayed, vbuf)
        } else {
            let mut addr = self.graphics_fetch_addr(now | (delayed & 0x20), vbuf);
            if (now ^ delayed) & 0x20 != 0 {
                let from = self.graphics_fetch_addr(delayed, vbuf);
                let to = self.graphics_fetch_addr(now, vbuf);
                if !memory.is_character_rom(self.vram_addr(from))
                    && memory.is_character_rom(self.vram_addr(to))
                {
                    addr = (from & 0x00FF) | (to & 0x3F00);
                }
            }
            addr
        };
        GraphicsData {
            gbuf: memory.read_vram(self.vram_addr(addr)),
            vbuf,
            cbuf,
        }
    }

    /// Accumulate sprite-sprite (`$D01E`) and sprite-background (`$D01F`)
    /// collisions from this cycle's sprite coverage, and raise the collision
    /// IRQs on the first hit. Runs every cycle — including the border and
    /// retrace — because the draw stage shifts sprite pixels out everywhere,
    /// and hardware detects collisions wherever that happens, not only inside
    /// the visible window. `gfx_fg_mask` is zero off the display window, so
    /// only sprite-sprite collisions register there.
    fn accumulate_sprite_collisions(&mut self) {
        let fg_mask = self.gfx_fg_mask;
        for px in 0..8usize {
            let cov = self.sprite_cycle_cov[px];
            if cov.count_ones() >= 2 {
                self.sprite_sprite_collision |= cov;
            }
            if cov != 0 && (fg_mask >> px) & 1 != 0 {
                self.sprite_bg_collision |= cov;
            }
        }

        if self.sprite_sprite_collision != 0 && !self.sprite_sprite_irq_latched {
            self.sprite_sprite_irq_latched = true;
            self.irq_status |= 0x04;
        }
        if self.sprite_bg_collision != 0 && !self.sprite_bg_irq_latched {
            self.sprite_bg_irq_latched = true;
            self.irq_status |= 0x02;
        }
    }

    /// Each sprite's leftmost framebuffer X (VIC X + the sprite-to-screen
    /// offset, honouring the `$D010` high bits).
    fn sprite_fb_x_array(&self) -> [i32; 8] {
        let mut x = [0i32; 8];
        for (i, slot) in x.iter_mut().enumerate() {
            let sprite_x = u16::from(self.regs[i * 2])
                | if self.regs[0x10] & (1 << i) != 0 {
                    256
                } else {
                    0
                };
            *slot = i32::from(sprite_x) + i32::from(SPRITE_X_TO_FB);
        }
        x
    }

    /// Each sprite's Y position (`$D001+2i`).
    fn sprite_y_array(&self) -> [u8; 8] {
        let mut y = [0u8; 8];
        for (i, slot) in y.iter_mut().enumerate() {
            *slot = self.regs[1 + i * 2];
        }
        y
    }

    /// Chain stage (VICE `vicii-cycle.c` sprite events): run MCBASE update
    /// (cyc 16), DMA check (55/56), expansion check (56), and display check
    /// (58), then the chain-driven MC-addressed p/s-access filling `chain_data`.
    ///
    /// The Y compare is **VICE-literal** (`Y == raster_line`, no `+1`) so
    /// per-line `$D015`/`$D001` writes are sampled at VICE's cycles, and
    /// **non-wrapping** (activation gated to `raster_line <= 255`) to suppress
    /// the raster-306 re-match VICE also hides (mechanism unpinned). The draw
    /// stage (`run_sprite_draw_cycle`) consumes the display bits + data.
    fn advance_sprite_chain(&mut self, memory: &dyn VicMemory) {
        let c = self.raster_cycle;
        let enable = self.regs[0x15];
        let y = self.sprite_y_array();
        let raster_low = self.raster_line as u8;

        if c == 16 {
            self.chain.update_mcbase();
        }
        if c == self.timing.chk_dma[0] || c == self.timing.chk_dma[1] {
            self.chain.check_dma(enable, y, raster_low);
        }
        if c == self.timing.chk_exp {
            self.chain.check_exp(self.regs[0x17]);
        }
        if c == self.timing.chk_disp {
            self.chain.check_display(enable, y, raster_low);
        }

        if let Some((i, _)) = self.sprite_paccess_cycle(c) {
            self.chain_paccess(memory, i);
        }
        if let Some(i) = self.sprite_saccess_cycle(c) {
            self.chain_saccess(memory, i);
        }
    }

    /// Draw stage (VICE `vicii-draw-cycle.c` `draw_sprites8`): produce this
    /// cycle's 8 raw sprite pixels into `sprite_cycle_px`, interleaving the
    /// per-pixel DMA housekeeping — deactivate on the s-access (pixel 2), halt on
    /// the p-access (pixel 3), latch pending + load data on the s-access
    /// (pixel 4), un-halt on the s-access (pixel 7). Halted sprites freeze their
    /// shift register (the sprite-fetch artifacts). Runs every cycle; the
    /// foreground-priority composite happens in `render_pixels`.
    fn run_sprite_draw_cycle(&mut self) {
        let c = self.raster_cycle;
        let expx = self.regs[0x1D];
        let dma0 = self.sprite_paccess_cycle(c).map(|(i, _)| i);
        let dma2 = self.sprite_saccess_cycle(c);
        let xpos_base = (i32::from(c) - i32::from(FIRST_VISIBLE_CYCLE)) * 8;

        self.sprite_sequencer
            .set_x_positions(self.sprite_fb_x_array());
        let hmos = self.model.has_grey_dot();

        for px in 0..8usize {
            match px {
                2 => {
                    if let Some(i) = dma2 {
                        self.sprite_sequencer.clear_active(i);
                    }
                }
                3 => {
                    if let Some(i) = dma0 {
                        self.sprite_sequencer.set_halt(i);
                    }
                }
                4 => {
                    if c == self.timing.chk_disp {
                        self.sprite_sequencer.set_pending(self.chain.display_bits());
                    }
                    if let Some(i) = dma2 {
                        let d = self.chain_data[i];
                        let data =
                            (u32::from(d[0]) << 16) | (u32::from(d[1]) << 8) | u32::from(d[2]);
                        self.sprite_sequencer.load_data(i, data);
                    }
                }
                6 if hmos => {
                    self.sprite_sequencer.set_mc_bits_hmos(self.regs[0x1C]);
                }
                7 => {
                    if !hmos {
                        self.sprite_sequencer.set_mc_bits(self.regs[0x1C]);
                    }
                    if let Some(i) = dma2 {
                        self.sprite_sequencer.clear_halt(i);
                    }
                }
                _ => {}
            }
            let drawn = self
                .sprite_sequencer
                .draw_pixel(xpos_base + px as i32, expx);
            self.sprite_cycle_px[px] = drawn.winner;
            self.sprite_cycle_cov[px] = drawn.coverage;
        }
    }

    /// Chain p-access: read the sprite pointer and data byte 0 addressed by MC,
    /// latch the pointer base, advance MC. Gated by the chain's DMA state.
    fn chain_paccess(&mut self, memory: &dyn VicMemory, i: usize) {
        if !self.chain.dma_active(i) {
            return;
        }
        let ptr_addr = self.screen_base() + 0x03F8 + i as u16;
        let base = u16::from(memory.read_vram(self.vram_addr(ptr_addr))) << 6;
        self.chain_fetch_base[i] = base;
        let mc = self.chain.mc(i);
        self.chain_data[i][0] = memory.read_vram(self.vram_addr(base + u16::from(mc)));
        // The sprite byte is the VIC's last bus access — drives open-bus reads
        // ($2F-$3F). (Was set by the removed overlay fetch; the chain reads the
        // same steady-state bytes, so this keeps open-bus behaviour.)
        self.last_bus_data = self.chain_data[i][0];
        self.chain.advance_mc(i);
    }

    /// Chain s-access: read data bytes 1 and 2 (advancing MC) into `chain_data`.
    /// The draw stage loads them into the shift register at pixel 4 of this
    /// cycle (VICE `update_sprite_data`).
    fn chain_saccess(&mut self, memory: &dyn VicMemory, i: usize) {
        if !self.chain.dma_active(i) {
            return;
        }
        let base = self.chain_fetch_base[i];
        let mc1 = self.chain.mc(i);
        self.chain_data[i][1] = memory.read_vram(self.vram_addr(base + u16::from(mc1)));
        self.chain.advance_mc(i);
        let mc2 = self.chain.mc(i);
        self.chain_data[i][2] = memory.read_vram(self.vram_addr(base + u16::from(mc2)));
        self.last_bus_data = self.chain_data[i][2];
        self.chain.advance_mc(i);
    }

    #[cfg(test)]
    fn is_sprite_dma_stealing(&self) -> bool {
        let c = self.raster_cycle;
        let cpl = self.cycles_per_line;
        // A sprite steals the bus on its p-access and s-access (the next
        // cycle), per the model's schedule.
        self.timing
            .paccess
            .iter()
            .enumerate()
            .any(|(i, &(p, _))| self.chain.dma_active(i) && (c == p || c == (p + 1) % cpl))
    }

    fn badline_ba_low(&self) -> bool {
        self.is_badline
            && match self.late_badline_fetches_remaining {
                Some(remaining) => remaining != 0,
                None => (12..=54).contains(&self.raster_cycle),
            }
    }

    fn badline_c_access_active(&self) -> bool {
        self.is_badline
            && match self.late_badline_fetches_remaining {
                Some(remaining) => remaining != 0,
                None => (15..=54).contains(&self.raster_cycle),
            }
    }

    fn sprite_ba_low(&self) -> bool {
        let c = self.raster_cycle;
        let cpl = self.cycles_per_line;
        // BA drops for the three cycles before a sprite's p-access through its
        // s-access (a 5-cycle window), per the model's schedule.
        self.timing.paccess.iter().enumerate().any(|(i, &(p, _))| {
            if !self.chain.dma_active(i) {
                return false;
            }
            let ba_start = (p + cpl - 3) % cpl;
            let ba_end = (p + 1) % cpl;
            if ba_start <= ba_end {
                c >= ba_start && c <= ba_end
            } else {
                c >= ba_start || c <= ba_end
            }
        })
    }

    fn screen_base(&self) -> u16 {
        u16::from((self.regs[0x18] >> 4) & 0x0F) * 0x0400
    }

    fn char_base(&self) -> u16 {
        u16::from((self.regs[0x18] >> 1) & 0x07) * 0x0800
    }

    fn bitmap_base(&self) -> u16 {
        if self.regs[0x18] & 0x08 != 0 {
            0x2000
        } else {
            0x0000
        }
    }

    /// The engine cycle whose CPU access first sees the current line.
    ///
    /// The engine starts each line at its relabelled last cycle (engine 0,
    /// VICE cycle 63), but the raster counter the CPU reads advances on the
    /// Phi2 half of cycle 1, and on cycle 2 for line 0, where the frame
    /// starts. VICE x64sc does the same in `vicii_cycle` ("Handle end of
    /// line" and `vicii_cycle_start_of_frame`, `viciisc/vicii-cycle.c`).
    const fn cpu_line_edge_cycle(&self) -> u8 {
        if self.raster_line == 0 { 2 } else { 1 }
    }

    /// The engine cycle of the CPU access that follows the latest tick.
    const fn cpu_access_cycle(&self) -> u8 {
        if self.raster_cycle == 0 {
            self.cycles_per_line - 1
        } else {
            self.raster_cycle - 1
        }
    }

    /// The raster counter during the current tick: the previous line on the
    /// engine cycles before the line edge.
    const fn counter_line(&self) -> u16 {
        if self.raster_cycle >= self.cpu_line_edge_cycle() {
            self.raster_line
        } else if self.raster_line == 0 {
            self.lines_per_frame - 1
        } else {
            self.raster_line - 1
        }
    }

    /// The raster line as the CPU sees it during the access that follows
    /// this tick: the previous line until the line edge.
    #[must_use]
    pub const fn cpu_visible_raster_line(&self) -> u16 {
        // `raster_cycle` already names the next cycle, so the access just
        // made belongs to `raster_cycle - 1` (engine 62 when it is 0).
        if self.raster_cycle > self.cpu_line_edge_cycle() {
            self.raster_line
        } else if self.raster_line == 0 {
            self.lines_per_frame - 1
        } else {
            self.raster_line - 1
        }
    }

    /// Read a VIC-II register.
    pub fn read(&mut self, reg: u8) -> u8 {
        // Per reference: $D019 bits 6:4 read as 1, $D01A bits 7:4 read
        // as 1, and unused bits on colour regs ($D020-$D02E) read as 1.
        match reg & 0x3F {
            0x11 => {
                (self.regs[0x11] & 0x7F)
                    | if self.cpu_visible_raster_line() & 0x100 != 0 {
                        0x80
                    } else {
                        0x00
                    }
            }
            0x12 => (self.cpu_visible_raster_line() & 0xFF) as u8,
            0x19 => {
                let composite = if (self.irq_status & self.irq_enable & 0x0F) != 0 {
                    0x80
                } else {
                    0x00
                };
                self.irq_status | composite | 0x70
            }
            0x1A => (self.irq_enable & 0x0F) | 0xF0,
            0x1E => {
                let val = self.sprite_sprite_collision;
                self.sprite_sprite_collision = 0;
                self.sprite_sprite_irq_latched = false;
                val
            }
            0x1F => {
                let val = self.sprite_bg_collision;
                self.sprite_bg_collision = 0;
                self.sprite_bg_irq_latched = false;
                val
            }
            r @ 0x20..=0x2E => self.regs[r as usize] | 0xF0,
            // Sprite coordinates ($00-$10), control/pointer registers
            // ($13-$18) and the sprite priority/multicolour/expand-X
            // registers ($1B-$1D) are all readable and return the last
            // written value — exactly what the hardware does, and what
            // read-modify-write movement code (`inc $d000`, `dec $d001`)
            // depends on. Only the special-cased registers above diverge.
            r @ (0x00..=0x10 | 0x13..=0x18 | 0x1B..=0x1D) => self.regs[r as usize],
            // $2F-$3F are unused; modelled as open bus.
            _ => self.last_bus_data,
        }
    }

    /// Read a register without side effects.
    #[must_use]
    pub fn peek(&self, reg: u8) -> u8 {
        match reg & 0x3F {
            0x11 => {
                (self.regs[0x11] & 0x7F)
                    | if self.cpu_visible_raster_line() & 0x100 != 0 {
                        0x80
                    } else {
                        0x00
                    }
            }
            0x12 => (self.cpu_visible_raster_line() & 0xFF) as u8,
            // peek() returns the same composite IRR, but we keep the
            // raw peek semantics — callers that want the canonical
            // silicon-observable read mask should use read() instead.
            0x19 => {
                self.irq_status
                    | if (self.irq_status & self.irq_enable & 0x0F) != 0 {
                        0x80
                    } else {
                        0x00
                    }
            }
            0x1A => self.irq_enable & 0x0F,
            0x1E => self.sprite_sprite_collision,
            0x1F => self.sprite_bg_collision,
            r if r <= 0x2E => self.regs[r as usize],
            _ => self.last_bus_data,
        }
    }

    /// Write a VIC-II register.
    pub fn write(&mut self, reg: u8, value: u8) {
        let r = (reg & 0x3F) as usize;
        let old = if r < self.regs.len() { self.regs[r] } else { 0 };
        if r < self.regs.len() {
            self.regs[r] = value;
        }

        if (0x20..=0x2E).contains(&r) {
            // Two writes between ticks (a debugger poke after the CPU's
            // access) keep the value the colour stage still holds.
            let previous = match self.colour_write {
                Some(write) if usize::from(write.register) == r => write.previous,
                _ => old,
            };
            self.colour_write = Some(ColourRegisterWrite {
                register: r as u8,
                previous,
            });
        }

        match reg & 0x3F {
            0x11 => {
                self.pending_d011_write_cycle = Some(self.cpu_access_cycle());
                self.raster_compare =
                    (self.raster_compare & 0x00FF) | (u16::from(value & 0x80) << 1);
            }
            0x12 => {
                self.raster_compare = (self.raster_compare & 0x0100) | u16::from(value);
            }
            0x19 => {
                self.irq_status &= !value & 0x0F;
            }
            0x1A => {
                self.irq_enable = value & 0x0F;
            }
            // Sprite crunch: a `$D017` change feeds the fetch chain's crunch
            // bit-math (gated on the crunch cycle).
            0x17 if value != old => {
                // VICE crunches on a write in cycle 15 (`ChkSprCrunch`).
                self.chain.write_d017(value, self.cpu_access_cycle() == 15);
            }
            _ => {}
        }

        self.irq = (self.irq_status & self.irq_enable & 0x0F) != 0;
    }

    /// Whether the IRQ pin is asserted.
    #[must_use]
    pub const fn irq_active(&self) -> bool {
        self.irq
    }

    /// Whether BA is asserted low.
    #[must_use]
    pub const fn ba_is_low(&self) -> bool {
        self.ba_low
    }

    /// Whether AEC is low and the VIC-II currently owns the Phi2 bus.
    #[must_use]
    pub const fn aec_is_low(&self) -> bool {
        self.cpu_stalled
    }

    /// Consecutive BA-low Phi2 cycles, saturated at four.
    #[must_use]
    pub const fn ba_low_cycles(&self) -> u8 {
        self.ba_low_cycles
    }

    /// Whether badline matrix DMA contributed to BA on the most recent Phi2.
    #[must_use]
    pub const fn badline_ba_is_low(&self) -> bool {
        self.badline_ba_low
    }

    /// Whether sprite DMA contributed to BA on the most recent Phi2.
    #[must_use]
    pub const fn sprite_ba_is_low(&self) -> bool {
        self.sprite_ba_low
    }

    /// Whether the most recent Phi2 attempted a video-matrix c-access.
    #[must_use]
    pub const fn c_access_is_active(&self) -> bool {
        self.c_access_active
    }

    /// CPU completion phase of a `$D011` write awaiting the next VIC tick.
    #[must_use]
    pub const fn pending_d011_write_cycle(&self) -> Option<u8> {
        self.pending_d011_write_cycle
    }

    /// Whether the current badline uses the explicit post-VIC far-edge window.
    #[must_use]
    pub const fn uses_late_badline_window(&self) -> bool {
        self.late_badline_fetches_remaining.is_some()
    }

    /// Remaining matrix accesses in an explicit post-VIC far-edge window.
    /// `None` identifies the established ordinary/earlier-forced schedule;
    /// `Some(0)` identifies an exhausted far-edge window whose display state
    /// may still be active.
    #[must_use]
    pub const fn late_badline_fetches_remaining(&self) -> Option<u8> {
        self.late_badline_fetches_remaining
    }

    /// Number of forced-badline output cells still sourced from the idle
    /// C/V/G pipeline.
    #[must_use]
    pub const fn forced_badline_output_delay(&self) -> u8 {
        self.forced_badline_output_delay
    }

    /// Whether the far-edge C-data carry network remains inside its bounded
    /// 40-clock eligibility window.
    #[must_use]
    pub const fn forced_badline_cdata_carry_pending(&self) -> bool {
        self.forced_badline_cdata_carry.is_some()
    }

    /// Live VMLI destination for the next eligible C-data merge.
    #[must_use]
    pub const fn forced_badline_cdata_destination_vmli(&self) -> Option<u8> {
        match self.forced_badline_cdata_carry {
            Some(_) => Some(self.vmli),
            None => None,
        }
    }

    /// Compatibility alias for the destination VMLI exposed before routing
    /// version 7 made its live meaning explicit.
    #[must_use]
    pub const fn forced_badline_cdata_carry_slot(&self) -> Option<u8> {
        self.forced_badline_cdata_destination_vmli()
    }

    /// Cycles left in the bounded far-edge C-data carry eligibility window.
    #[must_use]
    pub const fn forced_badline_cdata_eligibility_cycles_remaining(&self) -> Option<u8> {
        match self.forced_badline_cdata_carry {
            Some(carry) => Some(40u8.saturating_sub(carry.age.saturating_sub(1))),
            None => None,
        }
    }

    /// Compatibility alias for the bounded eligibility lifetime exposed
    /// before routing version 7 distinguished it from the propagated value.
    #[must_use]
    pub const fn forced_badline_cdata_carry_cycles_remaining(&self) -> Option<u8> {
        self.forced_badline_cdata_eligibility_cycles_remaining()
    }

    /// Age of the forced-badline C-data carry origin in VIC clocks.
    #[must_use]
    pub const fn forced_badline_cdata_carry_age(&self) -> Option<u8> {
        match self.forced_badline_cdata_carry {
            Some(carry) => Some(carry.age),
            None => None,
        }
    }

    /// Selected 12-bit value propagated by the previous C-data merge.
    #[must_use]
    pub const fn forced_badline_cdata_carry_value(&self) -> Option<u16> {
        match self.forced_badline_cdata_carry {
            Some(carry) => Some(carry.carry),
            None => None,
        }
    }

    /// Whether the display sequencer is in idle state.
    #[must_use]
    pub const fn idle_state(&self) -> bool {
        self.idle_state
    }

    /// Set the active VIC bank.
    pub fn set_bank(&mut self, bank: u8) {
        self.vic_bank = bank & 0x03;
    }

    /// Current VIC bank.
    #[must_use]
    pub const fn bank(&self) -> u8 {
        self.vic_bank
    }

    /// Trigger the light-pen latch once per frame, at the position of the
    /// cycle after the latest tick.
    ///
    /// VICE x64sc latches the light pen one cycle after the input falls
    /// (`vicii_set_light_pen`, `viciisc/vicii-lightpen.c`). LPX is half the
    /// X coordinate of that cycle's Phi1 (the `xpos` column of
    /// `viciisc/vicii-chip-model.c`) plus two on the NMOS 6567/6569, and the
    /// latch raises the light-pen interrupt. The frame's last line latches
    /// only on its first cycle.
    pub fn trigger_light_pen(&mut self) {
        self.latch_light_pen(false);
    }

    /// Drive the light-pen input: `true` while the line is held low. On the
    /// C64 the input is CIA 1 port B bit 4, which the keyboard matrix and the
    /// control port 1 fire button also pull low.
    pub fn set_light_pen_line(&mut self, low: bool) {
        if low && !self.lp_line_low {
            self.latch_light_pen(false);
        }
        self.lp_line_low = low;
    }

    fn latch_light_pen(&mut self, retrigger: bool) {
        if self.lp_triggered {
            return;
        }
        self.lp_triggered = true;

        let line = self.counter_line();
        let cycle = if self.raster_cycle == 0 {
            self.cycles_per_line
        } else {
            self.raster_cycle
        };
        if line == self.lines_per_frame - 1 && cycle > 1 {
            return;
        }
        let x = if retrigger {
            // VICE's start-of-frame retrigger position.
            if self.cycles_per_line == 65 {
                0xD5
            } else {
                0xD1
            }
        } else {
            (self.phi1_xpos(cycle) / 2 + 2) as u8
        };
        self.regs[0x13] = x;
        self.regs[0x14] = line as u8;
        self.irq_status |= 0x08;
        self.irq = (self.irq_status & self.irq_enable & 0x0F) != 0;
    }

    /// The X coordinate of a cycle's Phi1 half as VICE stores it in its cycle
    /// table: the `xpos` column rounded down to a multiple of 8
    /// (`cycle_get_xpos`, `viciisc/vicii-chip-model.h`), which makes cycle 1
    /// `$190` on PAL and `$198` on NTSC, then 8 dots a cycle, wrapping at the
    /// line's dot count. The 6567R8's cycles 62 and 63 share one coordinate.
    fn phi1_xpos(&self, cycle: u8) -> u16 {
        let n = u16::from(cycle) - 1;
        match self.cycles_per_line {
            63 => (0x190 + 8 * n) % 504,
            65 => (0x198 + 8 * n - if cycle >= 63 { 8 } else { 0 }) % 512,
            _ => (0x198 + 8 * n) % 512,
        }
    }

    /// Borrow the ARGB32 framebuffer.
    #[must_use]
    pub fn framebuffer(&self) -> &[u32] {
        &self.framebuffer
    }

    /// Rebuild the derived electrical cache from the serialized RGB frame.
    /// The board calls this before exposing a restored machine's output.
    pub fn rebuild_signal_codes(&mut self) {
        self.signal_codes = self
            .framebuffer
            .iter()
            .map(|rgb| PALETTE.iter().position(|entry| entry == rgb).unwrap_or(0) as u16)
            .collect();
    }

    /// Electrical colour codes captured at the final VIC pixel mux.
    #[must_use]
    pub fn signal_codes(&self) -> &[u16] {
        &self.signal_codes
    }

    /// Physical line length in dots, including blanking.
    #[must_use]
    pub fn signal_line_pixels(&self) -> u32 {
        u32::from(self.cycles_per_line) * 8
    }

    /// Framebuffer width in pixels.
    #[must_use]
    pub const fn framebuffer_width(&self) -> u32 {
        FB_WIDTH
    }

    /// Framebuffer height in pixels.
    #[must_use]
    pub fn framebuffer_height(&self) -> u32 {
        u32::from(self.last_visible_line - self.first_visible_line)
    }

    /// The last byte the VIC-II drove onto the data bus (its most recent
    /// fetch). Feeds open-bus reads: the upper nibble of a `$D800-$DBFF`
    /// colour-RAM read, and the unmapped registers `$2F-$3F`.
    #[must_use]
    pub const fn last_bus_data(&self) -> u8 {
        self.last_bus_data
    }

    /// Check and clear the frame-complete flag.
    pub fn take_frame_complete(&mut self) -> bool {
        let complete = self.frame_complete;
        self.frame_complete = false;
        if complete {
            // The frame's last two cells are still in the colour stage. The
            // machine takes the frame after the final cycle's CPU access, so
            // the registers are those the next ticks would use.
            self.flush_colour_stage();
        }
        complete
    }

    /// Current raster line.
    #[must_use]
    pub const fn raster_line(&self) -> u16 {
        self.raster_line
    }

    /// Current cycle within the raster line.
    #[must_use]
    pub const fn raster_cycle(&self) -> u8 {
        self.raster_cycle
    }

    /// Current character row within an 8-line character cell — the VIC-II row
    /// counter (RC), which drives the g-access sub-row addressing.
    #[must_use]
    pub const fn char_row(&self) -> u8 {
        self.rc
    }

    /// Whether the current line is a bad line.
    #[must_use]
    pub const fn is_badline(&self) -> bool {
        self.is_badline
    }

    /// Borrow the raw register file.
    #[must_use]
    pub const fn registers(&self) -> &[u8; 0x40] {
        &self.regs
    }

    /// Restore the raw register file from saved state.
    pub fn set_registers(&mut self, regs: &[u8; 0x40]) {
        self.regs = *regs;
        self.raster_compare = u16::from(self.regs[0x12]) | (u16::from(self.regs[0x11] & 0x80) << 1);
        self.irq_enable = self.regs[0x1A] & 0x0F;
    }

    /// Snapshot of the IRQ status register.
    #[must_use]
    pub const fn irq_status(&self) -> u8 {
        self.irq_status
    }

    /// Restore the IRQ status register.
    pub fn set_irq_status(&mut self, val: u8) {
        self.irq_status = val;
    }
}

impl Default for Vic {
    fn default() -> Self {
        Self::new(VicModel::Pal6569)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const LINES_PER_FRAME: u16 = 312;
    const CYCLES_PER_LINE: u8 = 63;
    const FIRST_VISIBLE_LINE: u16 = PAL_FIRST_VISIBLE_LINE;

    struct TestMemory {
        ram: Box<[u8; 0x10000]>,
        char_rom: Vec<u8>,
        colour_ram: Vec<u8>,
    }

    impl TestMemory {
        fn new(chargen: &[u8]) -> Self {
            Self {
                ram: Box::new([0; 0x10000]),
                char_rom: chargen.to_vec(),
                colour_ram: vec![0; 1024],
            }
        }

        fn with_colour(chargen: &[u8], colour_ram: Vec<u8>) -> Self {
            Self {
                ram: Box::new([0; 0x10000]),
                char_rom: chargen.to_vec(),
                colour_ram,
            }
        }

        fn ram_write(&mut self, addr: u16, value: u8) {
            self.ram[addr as usize] = value;
        }
    }

    impl VicMemory for TestMemory {
        fn read_vram(&self, addr: u16) -> u8 {
            let bank = (addr >> 14) & 0x03;
            let bank_addr = addr & 0x3FFF;
            if (bank == 0 || bank == 2) && (0x1000..0x2000).contains(&bank_addr) {
                self.char_rom[(bank_addr - 0x1000) as usize]
            } else {
                self.ram[addr as usize]
            }
        }

        fn is_character_rom(&self, addr: u16) -> bool {
            let bank = (addr >> 14) & 0x03;
            (bank == 0 || bank == 2) && (0x1000..0x2000).contains(&(addr & 0x3FFF))
        }

        fn read_colour(&self, offset: u16) -> u8 {
            self.colour_ram
                .get(offset as usize)
                .copied()
                .map(|v| v & 0x0F)
                .unwrap_or(0)
        }
    }

    fn make_vic_and_memory() -> (Vic, TestMemory) {
        make_vic_and_memory_model(VicModel::Pal6569)
    }

    fn make_vic_and_memory_model(model: VicModel) -> (Vic, TestMemory) {
        let chargen = vec![0xFF; 4096];
        let vic = Vic::new(model);
        let memory = TestMemory::new(&chargen);
        (vic, memory)
    }

    /// Tick until the VIC reaches exactly (`line`, `cycle`). Model-agnostic
    /// (unlike `advance_to`, which assumes PAL's cycle count); terminates within
    /// one frame for any valid target.
    fn advance_until(vic: &mut Vic, memory: &TestMemory, line: u16, cycle: u8) {
        while vic.raster_line() != line || vic.raster_cycle() != cycle {
            tick_vic(vic, memory);
        }
    }

    fn tick_vic(vic: &mut Vic, mem: &TestMemory) -> bool {
        tick_vic_with_cpu_data(vic, mem, 0)
    }

    fn tick_vic_with_cpu_data(vic: &mut Vic, mem: &TestMemory, cpu_data: u8) -> bool {
        vic.tick(mem, VicPhi2Bus { cpu_data })
    }

    fn advance_to(vic: &mut Vic, memory: &TestMemory, line: u16, cycle: u8) {
        let target = u32::from(line) * u32::from(CYCLES_PER_LINE) + u32::from(cycle);
        for _ in 0..target {
            tick_vic(vic, memory);
        }
    }

    /// The VIC-II two ticks later, once the colour stage has resolved every
    /// cell rendered so far. The extra ticks read blank memory; they render
    /// only later cells.
    fn settled(vic: &Vic) -> Vic {
        let mut vic = vic.clone();
        let blank = TestMemory::new(&[0; 4096]);
        tick_vic(&mut vic, &blank);
        tick_vic(&mut vic, &blank);
        vic
    }

    fn fb_pixel(vic: &Vic, fb_x: usize, fb_y: usize) -> u32 {
        settled(vic).framebuffer()[fb_y * FB_WIDTH as usize + fb_x]
    }

    /// Render one display line (100) carrying three sprites — a hires sprite, a
    /// multicolour sprite, and an X-expanded sprite — through the draw-stage
    /// sequencer, and return the whole framebuffer.
    fn render_three_sprite_scene() -> Vec<u32> {
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // DEN + display on
        vic.write(0x18, 0x14);
        vic.write(0x15, 0x07); // enable sprites 0,1,2
        vic.write(0x1C, 0x02); // sprite 1 multicolour
        vic.write(0x1D, 0x04); // sprite 2 X-expanded
        vic.write(0x25, 0x0A); // MC0
        vic.write(0x26, 0x0D); // MC1
        // Positions (all on line 100) and colours.
        vic.write(0x01, 100);
        vic.write(0x00, 180); // sprite 0 X
        vic.write(0x27, 0x01);
        vic.write(0x03, 100);
        vic.write(0x02, 120); // sprite 1 X
        vic.write(0x28, 0x03);
        vic.write(0x05, 100);
        vic.write(0x04, 60); // sprite 2 X
        vic.write(0x29, 0x05);
        // Sprite pointers → data blocks at $2000/$2040/$2080.
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x07F9, 0x81);
        memory.ram_write(0x07FA, 0x82);
        for k in 0..3u16 {
            memory.ram_write(0x2000 + k, [0xFF, 0x99, 0x3C][k as usize]);
            memory.ram_write(0x2040 + k, [0x1B, 0xE4, 0x5A][k as usize]);
            memory.ram_write(0x2080 + k, [0xC3, 0x66, 0xFF][k as usize]);
        }
        advance_to(&mut vic, &memory, 103, 0);
        settled(&vic).framebuffer().to_vec()
    }

    /// The draw-stage sequencer renders three coexisting sprites (hires +
    /// multicolour + X-expanded) on one line. In this *isolated* synthetic
    /// harness the continuous chain feed places the sprites one line later than
    /// their Y register (first-activation vs steady-state timing); real-program
    /// phase is validated by the testbench `sprite_sequencer_spritedma_parity`
    /// (0 px vs VICE). Assert the scene draws sprite pixels on that line.
    #[test]
    fn sprite_sequencer_renders_three_sprite_scene() {
        let fb = render_three_sprite_scene();
        let sq_row = (101 - FIRST_VISIBLE_LINE) as usize * FB_WIDTH as usize;
        let border = fb[0];
        let sprite_px = (0..FB_WIDTH as usize)
            .filter(|&x| fb[sq_row + x] != border)
            .count();
        assert!(
            sprite_px > 0,
            "scene should render sprite pixels on line 101"
        );
    }

    /// A deterministic full PAL frame rendered entirely from `TestMemory` — no
    /// ROMs, no CPU — exercising the render paths the audit flagged: standard
    /// text mode, the border flip-flops, palette mapping (border / background /
    /// foreground / sprite), and the draw-stage sprite sequencer.
    fn render_golden_scene() -> Vec<u32> {
        // Char 1's glyph is $AA (1010_1010) on every row, so each cell
        // alternates foreground and background pixels left to right.
        let mut chargen = vec![0xFFu8; 4096];
        for row in &mut chargen[8..16] {
            *row = 0xAA;
        }
        let mut memory = TestMemory::with_colour(&chargen, vec![0x01; 1024]); // white fg
        let mut vic = Vic::new(VicModel::Pal6569);

        vic.write(0x11, 0x1B); // DEN on, standard text mode, RSEL
        vic.write(0x16, 0x08); // CSEL, XSCROLL 0
        vic.write(0x18, 0x14); // screen matrix $0400, char base $1000 (char ROM)
        vic.write(0x20, 0x0E); // border light blue
        vic.write(0x21, 0x06); // background blue

        // The whole screen matrix is char 1.
        for offset in 0..0x0400u16 {
            memory.ram_write(0x0400 + offset, 0x01);
        }

        // One solid hires sprite so the mux is exercised.
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x00, 100); // X
        vic.write(0x01, 80); // Y
        vic.write(0x27, 0x03); // sprite colour cyan
        memory.ram_write(0x07F8, 0x80); // pointer → $2000
        for k in 0..63u16 {
            memory.ram_write(0x2000 + k, 0xFF);
        }

        advance_to(&mut vic, &memory, 311, 62); // a full PAL frame
        settled(&vic).framebuffer().to_vec()
    }

    fn fnv1a_u32(data: &[u32]) -> u64 {
        let mut hash = 0xcbf2_9ce4_8422_2325u64;
        for &word in data {
            for byte in word.to_le_bytes() {
                hash ^= u64::from(byte);
                hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
            }
        }
        hash
    }

    /// Render-accuracy regression floor (#768): a hermetic golden frame that
    /// runs in **default** CI, unlike the ROM-gated VICE-parity testbench. It
    /// locks the VIC-II's rendered output for a scene covering text-mode
    /// dispatch, the border flip-flops, palette mapping, and the sprite
    /// sequencer, so a regression to any of them fails loudly instead of
    /// slipping through. If this fails after an *intentional* VIC-II change,
    /// re-bless `GOLDEN_FRAME_HASH` (and bump `FRAME_ROUTING_VERSION` if
    /// catalogue frames move).
    #[test]
    fn render_accuracy_floor_locks_a_golden_frame() {
        const GOLDEN_FRAME_HASH: u64 = 0x0fe7_18f9_1ddb_3dfd;

        let fb = render_golden_scene();
        assert_eq!(fb.len(), (FB_WIDTH * FB_HEIGHT) as usize, "full PAL frame");

        // Named pixel-parity checks aid diagnosis; the hash is the full floor.
        let px = |x: usize, y: usize| fb[y * FB_WIDTH as usize + x];
        assert_eq!(px(0, 0), PALETTE[0x0E], "top-left is border colour");
        // Display starts at cycle 16 → fb_x 48. Char $AA: pixel 0 (bit 7) is
        // foreground, pixel 1 (bit 6) is background.
        assert_eq!(px(48, 80), PALETTE[0x01], "char foreground pixel");
        assert_eq!(px(49, 80), PALETTE[0x06], "char background pixel");

        let hash = fnv1a_u32(&fb);
        assert_eq!(
            hash, GOLDEN_FRAME_HASH,
            "VIC-II render drifted; re-bless if intentional. got {hash:#018x}"
        );
    }

    #[test]
    fn initial_state() {
        let mut vic = Vic::new(VicModel::Pal6569);
        assert_eq!(vic.raster_line(), 0);
        assert_eq!(vic.raster_cycle(), 0);
        assert!(!vic.irq_active());
        assert!(!vic.take_frame_complete());
        assert!(!vic.irq);
        assert!(!vic.ba_low);
    }

    #[test]
    fn raster_advances() {
        let (mut vic, memory) = make_vic_and_memory();
        for _ in 0..63 {
            tick_vic(&mut vic, &memory);
        }
        assert_eq!(vic.raster_line(), 1);
        assert_eq!(vic.raster_cycle(), 0);
    }

    #[test]
    fn frame_complete_after_full_frame() {
        let (mut vic, memory) = make_vic_and_memory();
        let total_cycles = u32::from(LINES_PER_FRAME) * u32::from(CYCLES_PER_LINE);
        for _ in 0..total_cycles {
            tick_vic(&mut vic, &memory);
        }
        assert!(vic.take_frame_complete());
        assert!(!vic.take_frame_complete());
    }

    #[test]
    fn raster_irq_fires_and_acknowledges() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x12, 1);
        vic.write(0x1A, 0x01);

        // Line 1 reaches the CPU on cycle 1 of line 1: 63 + 2 ticks.
        for _ in 0..65 {
            tick_vic(&mut vic, &memory);
        }
        assert!(vic.irq_active());
        assert!(vic.irq);

        vic.write(0x19, 0x01);
        assert!(!vic.irq_active());
        assert!(!vic.irq);
    }

    /// Seam 1 audit (`c64-architecture-review.md`): the raster-compare
    /// IRQ must fire at the exact phi2 cycle where the raster latch
    /// reaches the compare value — not one cycle early, not one cycle
    /// late. Demos use raster IRQs to drive single-scanline split
    /// effects; a one-cycle drift here breaks every raster effect.
    ///
    /// On the C64, the IRQ asserts at cycle 0 of the matching line
    /// (per Mäkelä §3.12). The `irq` pin is sampled by the CPU on the
    /// following phi2 high. The test asserts exactly that:
    ///   - At the end of the tick processing cycle 0 of line N,
    ///     `vic.irq` is true.
    ///   - At the end of the previous tick (line N-1, cycle 62 in PAL),
    ///     `vic.irq` is still false.
    ///   - At the end of the tick processing cycle 1 of line N,
    ///     `vic.irq` is still true (latched until ack).
    #[test]
    fn raster_irq_asserts_on_exact_phi2_of_compare_match() {
        let (mut vic, memory) = make_vic_and_memory();
        // Compare raster = 5. Enable raster IRQ.
        vic.write(0x12, 5);
        vic.write(0x1A, 0x01);

        // Engine 0 of line 5 is the relabelled last cycle of line 4 (VICE
        // cycle 63), so the CPU access after it still belongs to line 4.
        advance_to(&mut vic, &memory, 4, 62);
        tick_vic(&mut vic, &memory);
        assert_eq!((vic.raster_line(), vic.raster_cycle()), (5, 0));
        assert!(!vic.irq, "the CPU access of engine 62 is still on line 4");
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.raster_cycle(), 1);
        assert!(!vic.irq, "engine 0 is VICE cycle 63 of line 4");

        // Engine 1 is VICE cycle 1: its Phi2 half raises the IRQ, so the CPU
        // access of that cycle is the first to see it.
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.raster_cycle(), 2);
        assert!(vic.irq, "IRQ must assert on the Phi2 half of cycle 1");

        // It remains latched until acknowledged via $D019.
        tick_vic(&mut vic, &memory);
        assert!(vic.irq, "IRQ remains latched until ack");
        vic.write(0x19, 0x01);
        assert!(!vic.irq, "IRQ cleared after ack");
    }

    #[test]
    fn raster_irq_for_line_zero_asserts_on_cycle_two() {
        // Line 0 starts the frame one cycle later (VICE
        // `vicii_cycle_start_of_frame`), so its compare matches on cycle 2.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x12, 0);
        vic.write(0x1A, 0x01);
        advance_to(&mut vic, &memory, 1, 0);
        vic.write(0x19, 0x01);
        advance_until(&mut vic, &memory, 0, 2);
        assert!(!vic.irq, "line 0 is not yet visible to the CPU at cycle 1");
        tick_vic(&mut vic, &memory);
        assert!(vic.irq, "line 0 matches on the Phi2 half of cycle 2");
    }

    #[test]
    fn cpu_sees_the_line_edge_on_cycle_one() {
        let (mut vic, memory) = make_vic_and_memory();
        advance_to(&mut vic, &memory, 5, 62);
        // The access after engine 62 of line 5 reads 5.
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.raster_line(), 6, "the engine has wrapped");
        assert_eq!(vic.read(0x12), 5, "engine 62 belongs to line 5");
        // Engine 0 is VICE cycle 63 of line 5.
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.read(0x12), 5, "engine 0 is the last cycle of line 5");
        // Engine 1 is VICE cycle 1 of line 6.
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.read(0x12), 6, "the CPU sees line 6 from cycle 1");
        assert_eq!(vic.peek(0x12), 6, "peek agrees with the CPU read");
    }

    /// Seam 1 audit: with raster IRQ enabled but the compare value
    /// never matching, `vic.irq` must remain low across a full frame.
    /// Catches a class of bug where the IRQ asserts spuriously
    /// (e.g. comparing against an uninitialised latch).
    #[test]
    fn raster_irq_does_not_fire_when_compare_never_matches() {
        let (mut vic, memory) = make_vic_and_memory();
        // Compare raster = LINES_PER_FRAME (out of range — never
        // matches).
        let unreachable = LINES_PER_FRAME;
        vic.write(0x12, unreachable as u8);
        vic.write(0x11, ((unreachable >> 8) << 7) as u8);
        vic.write(0x1A, 0x01);

        let total_cycles = u32::from(LINES_PER_FRAME) * u32::from(CYCLES_PER_LINE);
        for _ in 0..total_cycles {
            tick_vic(&mut vic, &memory);
            assert!(
                !vic.irq,
                "spurious IRQ at line {} cycle {}",
                vic.raster_line, vic.raster_cycle
            );
        }
    }

    #[test]
    fn framebuffer_size() {
        let vic = Vic::new(VicModel::Pal6569);
        assert_eq!(
            settled(&vic).framebuffer().len(),
            FB_WIDTH as usize * FB_HEIGHT as usize
        );
    }

    #[test]
    fn register_read_write() {
        // Colour registers $D020-$D02E: bits 7:4 read as 1 per reference,
        // so writing $06 reads back as $F6 and $01 reads back as $F1.
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x20, 0x06);
        assert_eq!(vic.read(0x20), 0xF6);
        vic.write(0x21, 0x01);
        assert_eq!(vic.read(0x21), 0xF1);
    }

    #[test]
    fn sprite_position_registers_read_back_written_value() {
        // Sprite coordinate registers are readable and must return the
        // last written value — read-modify-write movement code
        // (`inc $d000` / `dec $d001`) relies on it. Regression for the
        // bug where these fell through to open-bus data, so every RMW
        // computed from stale data: the sprite jumped once then froze.
        let mut vic = Vic::new(VicModel::Pal6569);
        for reg in 0x00u8..=0x10 {
            vic.write(reg, 0xAB);
            assert_eq!(vic.read(reg), 0xAB, "register ${reg:02X} should read back");
        }
        // Read-modify-write semantics: write 172, decrement twice, expect 170.
        vic.write(0x01, 172);
        let after_two_dec = vic.read(0x01).wrapping_sub(1).wrapping_sub(1);
        vic.write(0x01, after_two_dec);
        assert_eq!(vic.read(0x01), 170);
    }

    #[test]
    fn bank_selection_masks_to_two_bits() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.set_bank(2);
        assert_eq!(vic.bank(), 2);
        vic.set_bank(5);
        assert_eq!(vic.bank(), 1);
    }

    #[test]
    fn sprite_renders_at_correct_position() {
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x01);
        vic.write(0x00, 172);
        vic.write(0x01, 100);
        vic.write(0x27, 0x01);
        vic.write(0x18, 0x14);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        vic.write(0x11, 0x1B);

        // Sprite Y = 100; the draw-stage sequencer draws it one line later in
        // this synthetic first-activation harness (line 101) — the +1 the
        // testbench validates as correct steady-state phase. X = 172 →
        // fb_x = 172 + 24 = 196.
        let target_line = 101u16;
        let target_cycle = 35u8;
        let cycles_to_target =
            u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..cycles_to_target {
            tick_vic(&mut vic, &memory);
        }

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let idx = fb_y * FB_WIDTH as usize + 196;
        assert_eq!(settled(&vic).framebuffer()[idx], PALETTE[1]);
    }

    #[test]
    fn bitmap_base_selection() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x18, 0x14);
        assert_eq!(vic.bitmap_base(), 0x0000);
        vic.write(0x18, 0x1C);
        assert_eq!(vic.bitmap_base(), 0x2000);
    }

    #[test]
    fn collision_registers_clear_on_read() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.sprite_sprite_collision = 0x05;
        vic.sprite_bg_collision = 0x0A;
        assert_eq!(vic.read(0x1E), 0x05);
        assert_eq!(vic.read(0x1E), 0x00);
        assert_eq!(vic.read(0x1F), 0x0A);
        assert_eq!(vic.read(0x1F), 0x00);
    }

    #[test]
    fn collision_peek_does_not_clear() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.sprite_sprite_collision = 0x03;
        assert_eq!(vic.peek(0x1E), 0x03);
        assert_eq!(vic.peek(0x1E), 0x03);
        assert_eq!(vic.read(0x1E), 0x03);
        assert_eq!(vic.read(0x1E), 0x00);
    }

    /// The draw-stage sequencer detects sprite-sprite collisions: two
    /// fully-overlapping sprites set both collision bits in `$D01E`.
    #[test]
    fn sprite_sequencer_sets_sprite_sprite_collision() {
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x03); // enable sprites 0, 1
        vic.write(0x00, 172);
        vic.write(0x01, 100); // sprite 0 at (172, 100)
        vic.write(0x02, 172);
        vic.write(0x03, 100); // sprite 1 at (172, 100) — fully overlapping
        vic.write(0x27, 0x01);
        vic.write(0x28, 0x02);
        vic.write(0x18, 0x14);
        vic.write(0x11, 0x1B);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x07F9, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        // Render past the sprites' display line (sequencer places them one line
        // later than geometry in this synthetic harness).
        advance_to(&mut vic, &memory, 103, 0);
        assert_eq!(
            vic.peek(0x1E) & 0x03,
            0x03,
            "sequencer should flag both sprites collided"
        );
    }

    #[test]
    fn sprite_bg_collision_set_on_foreground_overlap() {
        let chargen = vec![0xFF; 4096];
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x01;
            v
        };
        let mut memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x15, 0x01);
        vic.write(0x11, 0x1B);
        vic.write(0x18, 0x14);
        vic.write(0x00, 24);
        vic.write(0x01, 51);
        vic.write(0x27, 0x01);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);

        // Sprite Y = 51 draws at line 52 (sequencer first-activation +1); tick
        // past its pixels (X = 24 → fb_x 48 ≈ cycle 16) so the sprite-over-
        // foreground collision registers in `$D01F`.
        let target_line = 52u16;
        let target_cycle = 40u8;
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }

        let collision = vic.read(0x1F);
        assert_ne!(collision & 0x01, 0x00);
    }

    /// Sprites overlapping in the deep horizontal border still collide.
    /// A sprite at X = 392 draws at framebuffer X 416 — cycle 62, which
    /// `render_pixels` treats as off-window (`LAST_VISIBLE_CYCLE = 62`).
    /// The draw stage shifts the pixels out there regardless, so the
    /// sprite-sprite collision must still register in `$D01E`. Hardware
    /// detects collisions wherever sprite data is shifted, not only on-screen.
    #[test]
    fn sprite_sprite_collision_registers_in_the_border() {
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x03); // enable sprites 0, 1
        vic.write(0x00, 136); // sprite 0 low X
        vic.write(0x02, 136); // sprite 1 low X
        vic.write(0x10, 0x03); // $D010 high X bit for 0 and 1 → X = 392
        vic.write(0x01, 100);
        vic.write(0x03, 100); // both at Y = 100, fully overlapping
        vic.write(0x27, 0x01);
        vic.write(0x28, 0x02);
        vic.write(0x18, 0x14);
        vic.write(0x11, 0x1B);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x07F9, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        advance_to(&mut vic, &memory, 105, 0);
        assert_eq!(
            vic.peek(0x1E) & 0x03,
            0x03,
            "sprites colliding in the border should still set $D01E",
        );
    }

    #[test]
    fn invalid_mode_renders_black() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x7B);
        vic.write(0x20, 0x06);
        vic.write(0x21, 0x01);

        let target_line = DISPLAY_START_LINE + 3;
        let target_cycle = DISPLAY_START_CYCLE + 5;
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x = (target_cycle - FIRST_VISIBLE_CYCLE) as usize * 8;
        assert_eq!(fb_pixel(&vic, fb_x, fb_y), PALETTE[0]);
    }

    #[test]
    fn ecm_text_selects_background() {
        let chargen = vec![0x00; 4096];
        let mut memory = TestMemory::new(&chargen);
        // Screen codes the streaming c-access reads from the matrix at $0400
        // ($D018=0x14, text_row 0). ECM uses bits 7:6 to pick the background.
        memory.ram_write(0x0400, 0x00);
        memory.ram_write(0x0401, 0x40);
        memory.ram_write(0x0402, 0x80);
        memory.ram_write(0x0403, 0xC0);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x11, 0x5B);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x00);
        vic.write(0x22, 0x02);
        vic.write(0x23, 0x05);
        vic.write(0x24, 0x06);

        let target_line = DISPLAY_START_LINE + 3;
        let past_fetch = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + 16;
        for _ in 0..past_fetch {
            tick_vic(&mut vic, &memory);
        }

        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        assert_eq!(fb_pixel(&vic, fb_x0, fb_y), PALETTE[0]);

        tick_vic(&mut vic, &memory);
        assert_eq!(fb_pixel(&vic, fb_x0 + 8, fb_y), PALETTE[2]);

        tick_vic(&mut vic, &memory);
        assert_eq!(fb_pixel(&vic, fb_x0 + 16, fb_y), PALETTE[5]);

        tick_vic(&mut vic, &memory);
        assert_eq!(fb_pixel(&vic, fb_x0 + 24, fb_y), PALETTE[6]);
    }

    #[test]
    fn badline_ba_low_cycles_12_to_54() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        advance_to(&mut vic, &memory, 0x33, 0);

        for cycle in 0..CYCLES_PER_LINE {
            tick_vic(&mut vic, &memory);
            let expected = (12..=54).contains(&cycle);
            assert_eq!(vic.ba_low, expected);
        }
    }

    #[test]
    fn non_badline_does_not_assert_ba() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        advance_to(&mut vic, &memory, 0x34, 0);

        for _ in 0..CYCLES_PER_LINE {
            tick_vic(&mut vic, &memory);
            assert!(!vic.badline_ba_low());
        }
    }

    /// Seam 1 audit (`c64-architecture-review.md`): asserts the
    /// asymmetry between `ba_low` and `cpu_stalled` on a badline.
    /// `ba_low` covers cycles 12-54 (BA goes low 3 phi2 cycles before
    /// the VIC-II's badline DMA actually starts, so the NMOS 6510 has
    /// time to wind down outstanding bus operations). `cpu_stalled`
    /// covers only cycles 15-54 (the AEC-low window where the CPU is
    /// actually off the bus). The 3-cycle gap (12-14) is the canonical
    /// NMOS warm-up where writes complete and reads still stall via
    /// the RDY pin.
    #[test]
    fn badline_ba_low_leads_cpu_stalled_by_three_cycles() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        advance_to(&mut vic, &memory, 0x33, 0);

        for cycle in 0..CYCLES_PER_LINE {
            tick_vic(&mut vic, &memory);
            let expected_ba_low = (12..=54).contains(&cycle);
            let expected_cpu_stalled = (15..=54).contains(&cycle);
            assert_eq!(
                vic.ba_low, expected_ba_low,
                "cycle {cycle}: ba_low mismatch"
            );
            assert_eq!(
                vic.cpu_stalled, expected_cpu_stalled,
                "cycle {cycle}: cpu_stalled mismatch"
            );
            // Structural invariant: cpu_stalled → ba_low. The
            // converse is intentionally false during cycles 12-14.
            assert!(
                !vic.cpu_stalled || vic.ba_low,
                "cycle {cycle}: cpu_stalled set without ba_low — invariant broken"
            );
        }
    }

    /// Seam 1 audit: same asymmetry holds for sprite DMA. Each active
    /// sprite asserts BA for 5 cycles (55-59 for sprite 0, shifted by
    /// 2 per subsequent sprite) but the CPU is only fully stalled for
    /// the 2-cycle DMA fetch window (58-59 for sprite 0). The 3-cycle
    /// lead-in matches the badline pattern.
    #[test]
    fn sprite_ba_low_leads_cpu_stalled_by_three_cycles() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x15, 0x01); // sprite 0 enabled
        vic.write(0x01, 0); // sprite 0 Y position 0
        advance_to(&mut vic, &memory, 0, 55);

        // Step through cycle 55 onwards to observe BA + cpu_stalled.
        for cycle in 55..CYCLES_PER_LINE {
            tick_vic(&mut vic, &memory);
            let expected_ba_low = (55..=59).contains(&cycle);
            let expected_cpu_stalled = (58..=59).contains(&cycle);
            assert_eq!(
                vic.ba_low, expected_ba_low,
                "cycle {cycle}: sprite ba_low mismatch"
            );
            assert_eq!(
                vic.cpu_stalled, expected_cpu_stalled,
                "cycle {cycle}: sprite cpu_stalled mismatch"
            );
            assert!(
                !vic.cpu_stalled || vic.ba_low,
                "cycle {cycle}: cpu_stalled without ba_low — invariant broken"
            );
        }
    }

    /// Seam 1 audit: lock the full per-sprite cycle allocation table
    /// against Marko Mäkelä's "MOS 6567/6569 video controller" §3.8.
    /// Each of sprites 0-7 has its s-access pair at a deterministic
    /// pair of phi2 cycles, preceded by a 3-cycle BA warm-up:
    ///
    /// Sprite | BA low cycles | DMA cycles (cpu_stalled)
    /// 0      | 55..=59       | 58..=59
    /// 1      | 57..=61       | 60..=61
    /// 2      | 59..=63       | 62, 0   (cpu_stalled set even on
    /// 3      |  0..=4        | 1..=2    wrap; ba_low spans both
    /// 4      |  2..=6        | 3..=4    sides of the cycle-0 wrap)
    /// 5      |  4..=8        | 5..=6
    /// 6      |  6..=10       | 7..=8
    /// 7      |  8..=12       | 9..=10
    ///
    /// Verified by enabling each sprite in isolation (Y=0 so it's
    /// active on raster line 0) and walking from line 0 cycle 0
    /// through into line 1.
    #[test]
    fn each_sprite_steals_canonical_cycles() {
        // (sprite_index, expected (line, cycle) DMA pairs)
        const DMA_CYCLES: [(usize, &[(u16, u8)]); 8] = [
            (0, &[(0, 58), (0, 59)]),
            (1, &[(0, 60), (0, 61)]),
            (2, &[(0, 62), (1, 0)]),
            (3, &[(1, 1), (1, 2)]),
            (4, &[(1, 3), (1, 4)]),
            (5, &[(1, 5), (1, 6)]),
            (6, &[(1, 7), (1, 8)]),
            (7, &[(1, 9), (1, 10)]),
        ];
        for &(i, expected_dma) in &DMA_CYCLES {
            let (mut vic, memory) = make_vic_and_memory();
            vic.write(0x15, 1 << i); // only this sprite enabled
            // Y position 0 for whichever sprite we're testing.
            vic.write(0x01 + (i as u8) * 2, 0);

            // Walk from (0, 0). The sprite-DMA check fires at cycle 55
            // of line 0 (sprite_y=0, raster_line=0 → offset 0 < 21 →
            // ACTIVE). The DMA cycles fire at 58-59 of line 0 for
            // sprite 0, shifting through into line 1 for the rest.
            // We need to cover up to line 1 cycle 10 — one full
            // line + 11 cycles = CYCLES_PER_LINE + 11 ticks. Capture
            // the (line, cycle) currently being processed each tick.
            let mut observed_dma = Vec::new();
            for _ in 0..(u32::from(CYCLES_PER_LINE) + 11) {
                // Snapshot the cycle BEFORE the tick — tick increments
                // raster_cycle at the end, so vic.cpu_stalled set
                // during the tick corresponds to the pre-tick cycle.
                let pre_line = vic.raster_line;
                let pre_cycle = vic.raster_cycle;
                tick_vic(&mut vic, &memory);
                if vic.cpu_stalled {
                    observed_dma.push((pre_line, pre_cycle));
                }
            }
            let mut sorted_observed = observed_dma.clone();
            sorted_observed.sort_unstable();
            let mut sorted_expected: Vec<(u16, u8)> = expected_dma.to_vec();
            sorted_expected.sort_unstable();
            assert_eq!(
                sorted_observed, sorted_expected,
                "sprite {i}: cpu_stalled (line, cycle) pairs mismatch; got {observed_dma:?}, want {expected_dma:?}"
            );
        }
    }

    /// Seam 1 audit: when a sprite is disabled, its s-cycle pair must
    /// be free — no BA pull-down and no cpu_stalled assertion. The
    /// real silicon allocates the cycles based on the sprite enable
    /// register at the *end of the previous line*, and disabled
    /// sprites release their slot. This catches a regression where
    /// the schedule pre-reserves cycles regardless of enable.
    #[test]
    fn disabled_sprite_releases_its_cycles() {
        let (mut vic, memory) = make_vic_and_memory();
        // No sprites enabled.
        vic.write(0x15, 0x00);
        advance_to(&mut vic, &memory, LINES_PER_FRAME - 1, 0);
        for _ in 0..(u32::from(CYCLES_PER_LINE) + 13) {
            tick_vic(&mut vic, &memory);
            assert!(
                !vic.cpu_stalled,
                "line {} cycle {}: cpu_stalled fired with no sprites enabled",
                vic.raster_line, vic.raster_cycle
            );
            // Also no sprite BA — but badlines may still assert BA
            // on a separate condition. We're on line 0 / 1 with no
            // DEN set, so badlines aren't triggered.
            assert!(
                !vic.sprite_ba_low(),
                "line {} cycle {}: sprite_ba_low fired with no sprites enabled",
                vic.raster_line,
                vic.raster_cycle
            );
        }
    }

    #[test]
    fn sprite_ba_asserts_with_three_cycle_leadin() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x15, 0x01);
        vic.write(0x01, 0);
        advance_to(&mut vic, &memory, 0, 55);
        tick_vic(&mut vic, &memory);

        for cycle in 56..CYCLES_PER_LINE {
            let expected = (55..=59).contains(&cycle);
            assert_eq!(vic.sprite_ba_low(), expected);
            tick_vic(&mut vic, &memory);
        }
    }

    #[test]
    fn light_pen_latches_beam_position() {
        let (mut vic, memory) = make_vic_and_memory();
        for _ in 0..20 {
            tick_vic(&mut vic, &memory);
        }
        // 20 ticks leave the next cycle at 20, whose PAL Phi1 X is
        // ($190 + 19 * 8) mod 504 = $30. LPX is half that plus two.
        assert_eq!(vic.raster_cycle(), 20);
        vic.trigger_light_pen();
        assert_eq!(vic.peek(0x14), 0);
        assert_eq!(vic.peek(0x13), 0x1A);
        assert_ne!(vic.irq_status() & 0x08, 0, "the latch raises the LP IRQ");
    }

    #[test]
    fn light_pen_latches_once_per_frame() {
        let (mut vic, memory) = make_vic_and_memory();
        while vic.raster_line() < 50 {
            tick_vic(&mut vic, &memory);
        }
        vic.trigger_light_pen();
        let first_lpy = vic.peek(0x14);

        for _ in 0..200 {
            tick_vic(&mut vic, &memory);
        }
        vic.trigger_light_pen();
        assert_eq!(vic.peek(0x14), first_lpy);
    }

    #[test]
    fn unmapped_registers_return_last_bus_data() {
        let (mut vic, memory) = make_vic_and_memory();
        for _ in 0..(CYCLES_PER_LINE as u32 * (DISPLAY_START_LINE as u32 + 2)) {
            tick_vic(&mut vic, &memory);
        }
        assert_eq!(vic.read(0x2F), vic.peek(0x2F));
        assert_eq!(vic.read(0x30), vic.read(0x2F));
        assert_eq!(vic.read(0x3F), vic.read(0x2F));
    }

    #[test]
    fn xscroll_zero_renders_cell_unchanged() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x08);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x00);

        let target_line = DISPLAY_START_LINE + 3;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        vic.colour_row[0] = 0x01;
        tick_vic(&mut vic, &memory);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        for px in 0..8 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[1]);
        }
    }

    /// Advance by exactly N cycles (one tick per cycle).
    fn step_cycles(vic: &mut Vic, memory: &TestMemory, n: u32) {
        for _ in 0..n {
            tick_vic(vic, memory);
        }
    }

    /// Run until the next tick would execute (line, cycle). advance_to
    /// runs `line * cycles_per_line + cycle` ticks *from construction*,
    /// so call it only on a fresh VIC.
    #[test]
    fn vertical_ff_clears_on_first_display_line_with_den() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // RSEL=1, DEN=1, YSCROLL=3
        // Engine 0 of line 51 is still line 50 to the raster counter.
        advance_to(&mut vic, &memory, 51, 0);
        tick_vic(&mut vic, &memory);
        assert!(vic.border_vert_ff, "engine 0 still belongs to line 50");
        tick_vic(&mut vic, &memory); // cycle 1: the counter reaches line 51
        assert!(!vic.border_vert_ff, "vert FF should clear at line 51");
    }

    #[test]
    fn vertical_ff_sets_at_last_display_line() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // RSEL=1
        advance_to(&mut vic, &memory, 251, 0);
        tick_vic(&mut vic, &memory);
        assert!(!vic.border_vert_ff, "engine 0 still belongs to line 250");
        tick_vic(&mut vic, &memory); // cycle 1: the counter reaches line 251
        assert!(vic.border_vert_ff, "vert FF should set at line 251");
    }

    #[test]
    fn main_ff_clears_at_left_edge_when_vert_ff_off() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // RSEL=1, DEN=1
        vic.write(0x16, 0x08); // CSEL=1
        advance_to(&mut vic, &memory, 100, 16);
        tick_vic(&mut vic, &memory);
        assert!(!vic.border_vert_ff);
        assert!(!vic.border_main_ff, "main FF should clear at left edge");
    }

    #[test]
    fn open_border_trick_rsel_bit_flip_suppresses_vertical_ff() {
        // Open-border sequence: hold RSEL=1 through line 247 (so the
        // RSEL=0 set-rule never fires), then flip to RSEL=0 before
        // line 251 (so the RSEL=1 set-rule doesn't fire either).
        // Result: vert FF stays clear past the normal close point.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // RSEL=1, DEN=1
        // advance_to(248, 0) from a fresh VIC runs 248*63 = 15624 ticks
        // which covers lines 0-247 in full (including line 51 clear
        // and line 247 which doesn't fire the set-rule with RSEL=1).
        advance_to(&mut vic, &memory, 248, 0);
        assert!(!vic.border_vert_ff);
        // Flip RSEL to 0 before line 251.
        vic.write(0x11, 0x13);
        // Continue to line 252 (another 4 full lines = 4*63 = 252 ticks).
        step_cycles(&mut vic, &memory, 4 * u32::from(CYCLES_PER_LINE));
        assert!(
            !vic.border_vert_ff,
            "open-border trick should keep vert FF clear"
        );
    }

    #[test]
    fn naive_close_sets_vert_ff_at_line_247_rsel_zero() {
        // Control case: with RSEL=0 throughout, line 247 fires the
        // set-rule and the vert FF goes high as expected.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x13); // RSEL=0, DEN=1
        advance_to(&mut vic, &memory, 248, 0);
        assert!(vic.border_vert_ff, "RSEL=0 + line 247 should set vert FF");
    }

    #[test]
    fn xscroll_four_shifts_cell_right() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x0C);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x00);

        let target_line = DISPLAY_START_LINE + 3;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        vic.colour_row[0] = 0x01;
        tick_vic(&mut vic, &memory);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        for px in 0..4 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[0]);
        }
        for px in 4..8 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[1]);
        }
    }

    /// Render line 0x34 (display state, not a badline) with columns
    /// `col - 1`, `col` and `col + 1` in red, green and blue on black,
    /// starting at `from` XSCROLL and writing `to` in the CPU access of
    /// `col`'s g-access cycle. Returns the 24 dots of the three columns'
    /// cells.
    fn xscroll_write_in_column(col: u8, from: u8, to: u8) -> Vec<u32> {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x08 | from);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x00);

        let target_line = DISPLAY_START_LINE + 4;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        let col = usize::from(col);
        vic.colour_row[col - 1] = 0x02;
        vic.colour_row[col] = 0x05;
        if let Some(next) = vic.colour_row.get_mut(col + 1) {
            *next = 0x06;
        }
        step_cycles(&mut vic, &memory, col as u32 + 1);
        vic.write(0x16, 0x08 | to);
        step_cycles(&mut vic, &memory, 2);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x = (usize::from(DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) + col - 1) * 8;
        let frame = settled(&vic);
        let row = &frame.framebuffer()[fb_y * FB_WIDTH as usize..];
        row[fb_x..fb_x + 24].to_vec()
    }

    #[test]
    fn xscroll_write_in_a_g_access_cycle_moves_that_cell() {
        // XSCROLL 0 -> 2 in column 5's g-access cycle. Column 4 shows whole;
        // column 5 loads two dots late, so two zero-bit (`$D021`) dots
        // separate them; column 6 follows, also two dots late.
        let (black, red, green, blue) = (PALETTE[0], PALETTE[2], PALETTE[5], PALETTE[6]);
        let mut expected = vec![red; 8];
        expected.extend([black, black]);
        expected.extend([green; 8]);
        expected.extend([blue; 6]);
        assert_eq!(xscroll_write_in_column(5, 0, 2), expected);
    }

    #[test]
    fn smaller_xscroll_cuts_the_previous_cell_short() {
        // XSCROLL 3 -> 0 in column 5's g-access cycle. Column 4, loaded at
        // dot 3, loses its last three dots when column 5 loads at dot 0.
        let (green, red, blue) = (PALETTE[5], PALETTE[2], PALETTE[6]);
        let row = xscroll_write_in_column(5, 3, 0);
        assert_eq!(&row[3..8], &[red; 5]);
        assert_eq!(&row[8..16], &[green; 8]);
        assert_eq!(&row[16..24], &[blue; 8]);
    }

    #[test]
    fn xscroll_write_in_the_last_g_access_cycle_misses_column_39() {
        // The fetch window has closed by the time column 39's XSCROLL is
        // sampled, so a write in its g-access cycle (55) arrives too late.
        let (red, green) = (PALETTE[2], PALETTE[5]);
        let row = xscroll_write_in_column(39, 0, 2);
        assert_eq!(&row[..8], &[red; 8]);
        assert_eq!(&row[8..16], &[green; 8]);
    }

    /// Render line 0x34 (display state, not a badline) of solid blue text at
    /// `xscroll`, switch to an invalid mode (ECM and BMM, black) in the CPU
    /// access of column `col`'s g-access cycle, and return the 16 dots of
    /// columns `col - 1` and `col`.
    fn invalid_mode_write_in_column(model: VicModel, col: u8, xscroll: u8) -> Vec<u32> {
        let (mut vic, memory) = make_vic_and_memory_model(model);
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x08 | xscroll);
        vic.write(0x18, 0x14);

        let target_line = DISPLAY_START_LINE + 4;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        vic.colour_row = [0x06; 40];
        step_cycles(&mut vic, &memory, u32::from(col) + 1);
        vic.write(0x11, 0x7B);
        step_cycles(&mut vic, &memory, 2);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x = usize::from(DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE + col - 1) * 8;
        let frame = settled(&vic);
        let row = &frame.framebuffer()[fb_y * FB_WIDTH as usize..];
        row[fb_x..fb_x + 16].to_vec()
    }

    #[test]
    fn nmos_mode_change_takes_effect_at_dot_4_whatever_the_xscroll() {
        // The 6569 decodes ECM and BMM at the shift register's output. A
        // write in column 5's g-access cycle reaches it while column 4 is
        // shifting out, from dot 4, so the black starts there at any XSCROLL
        // instead of moving with the graphics.
        let (blue, black) = (PALETTE[6], PALETTE[0]);
        let mut expected = vec![blue; 4];
        expected.extend([black; 12]);
        for xscroll in [0, 5] {
            assert_eq!(
                invalid_mode_write_in_column(VicModel::Pal6569, 5, xscroll),
                expected,
                "XSCROLL {xscroll}"
            );
        }
    }

    #[test]
    fn hmos_mode_change_takes_effect_at_the_next_cycle_whatever_the_xscroll() {
        // The 8565 latches ECM and BMM after dot 7, so column 4 keeps the
        // old mode and column 5 starts in the new one.
        let (blue, black) = (PALETTE[6], PALETTE[0]);
        let mut expected = vec![blue; 8];
        expected.extend([black; 8]);
        for xscroll in [0, 5] {
            assert_eq!(
                invalid_mode_write_in_column(VicModel::Pal8565, 5, xscroll),
                expected,
                "XSCROLL {xscroll}"
            );
        }
    }

    /// On line 0x34 (display state, not a badline), with `$D011` = `before`,
    /// write `after` in the CPU access of column 5's g-access cycle and return
    /// the eight dots of column 6, the first g-access after the write. Every
    /// matrix entry is `$25` and every colour entry yellow; `$D021` is blue.
    fn column_after_d011_write(
        model: VicModel,
        memory: &mut TestMemory,
        d018: u8,
        before: u8,
        after: u8,
    ) -> Vec<u32> {
        let mut vic = Vic::new(model);
        vic.write(0x11, before);
        vic.write(0x16, 0x08);
        vic.write(0x18, d018);
        vic.write(0x21, 0x06);

        let target_line = DISPLAY_START_LINE + 4;
        advance_to(&mut vic, memory, target_line, DISPLAY_START_CYCLE);
        vic.screen_row = [0x25; 40];
        vic.colour_row = [0x07; 40];
        step_cycles(&mut vic, memory, 6);
        vic.write(0x11, after);
        step_cycles(&mut vic, memory, 3);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x = usize::from(DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE + 6) * 8;
        let frame = settled(&vic);
        let row = &frame.framebuffer()[fb_y * FB_WIDTH as usize..];
        row[fb_x..fb_x + 8].to_vec()
    }

    /// Bank 0 with a solid bitmap at `$2000` and blank characters at `$3000`.
    fn solid_bitmap_blank_ram_characters() -> TestMemory {
        let mut memory = TestMemory::new(&[0; 4096]);
        for addr in 0x2000..0x3000 {
            memory.ram_write(addr, 0xFF);
        }
        memory
    }

    #[test]
    fn falling_bmm_reaches_the_g_access_a_cycle_late() {
        // Bitmap to text in column 5's cycle: column 6 still fetches the
        // solid bitmap, shown as text in the colour entry's yellow. Character
        // data would be blank, showing `$D021`.
        for model in [VicModel::Pal6569, VicModel::Pal8565] {
            let mut memory = solid_bitmap_blank_ram_characters();
            assert_eq!(
                column_after_d011_write(model, &mut memory, 0x1C, 0x3B, 0x1B),
                vec![PALETTE[7]; 8],
                "{model:?}"
            );
        }
    }

    #[test]
    fn rising_bmm_reaches_the_g_access_at_once_on_the_6569_only() {
        // Text to bitmap in column 5's cycle. Column 6 shows hires bitmap
        // colours from the matrix entry `$25`: red where the solid bitmap
        // was fetched, green for the blank character the 8565 still fetches.
        let mut memory = solid_bitmap_blank_ram_characters();
        assert_eq!(
            column_after_d011_write(VicModel::Pal6569, &mut memory, 0x1C, 0x1B, 0x3B),
            vec![PALETTE[2]; 8]
        );
        let mut memory = solid_bitmap_blank_ram_characters();
        assert_eq!(
            column_after_d011_write(VicModel::Pal8565, &mut memory, 0x1C, 0x1B, 0x3B),
            vec![PALETTE[5]; 8]
        );
    }

    #[test]
    fn falling_bmm_into_the_character_rom_mixes_the_two_addresses() {
        // Bitmap at `$0000` (RAM, blank) to text from the character ROM at
        // `$1000` in column 5's cycle. Column 6's g-access takes its low
        // byte from the bitmap address and the rest from the character
        // address. Only that byte is solid in the ROM, so only the mixed
        // address shows the yellow colour entry.
        let mut probe = Vic::new(VicModel::Pal6569);
        probe.write(0x11, 0x3B);
        let probe_memory = TestMemory::new(&[0; 4096]);
        advance_to(
            &mut probe,
            &probe_memory,
            DISPLAY_START_LINE + 4,
            DISPLAY_START_CYCLE,
        );
        step_cycles(&mut probe, &probe_memory, 6);
        let (vc, rc) = (probe.vc, u16::from(probe.rc));
        let bitmap_low = (vc * 8 + rc) & 0x00FF;
        let character = 0x25 * 8 + rc;
        assert_ne!(
            bitmap_low,
            character & 0x00FF,
            "the two addresses must differ"
        );

        let mut chargen = [0; 4096];
        chargen[usize::from((character & 0x0F00) | bitmap_low)] = 0xFF;
        let mut memory = TestMemory::new(&chargen);
        assert_eq!(
            column_after_d011_write(VicModel::Pal6569, &mut memory, 0x14, 0x3B, 0x1B),
            vec![PALETTE[7]; 8]
        );
    }

    #[test]
    fn late_badline_uses_invalid_matrix_data_until_aec_is_low() {
        let chargen = vec![0u8; 4096];
        let mut colours = vec![0u8; 1024];
        colours[0x123] = 0x0D;
        let mut memory = TestMemory::with_colour(&chargen, colours);
        memory.ram_write(0x0123, 0x43);

        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0x30;
        vic.raster_cycle = 15;
        vic.den_latch = true;
        vic.vcbase = 0x0120;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.is_badline = false;
        // Line $30 has vertical phase zero. Keep it non-bad through cycle 15.
        vic.write(0x11, 0x11);

        tick_vic(&mut vic, &memory);
        assert_eq!(vic.raster_cycle(), 16);
        assert!(!vic.is_badline());

        // Changing YSCROLL after cycle 15 creates the late badline. Cycle 16
        // still performs its Phi1 access in idle state. BA has had no lead
        // time, so the attempted Phi2 c-access stores the disconnected matrix
        // value and the CPU-side low nibble in slot zero.
        vic.write(0x11, 0x10);
        assert_eq!(vic.pending_d011_write_cycle(), Some(15));
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert!(vic.is_badline());
        assert!(!vic.uses_late_badline_window());
        assert_eq!(vic.late_badline_fetches_remaining(), None);
        assert!(vic.badline_ba_is_low());
        assert!(!vic.sprite_ba_is_low());
        assert!(vic.c_access_is_active());
        assert_eq!(vic.pending_d011_write_cycle(), None);
        assert!(vic.ba_low);
        assert!(!vic.aec_is_low());
        assert_eq!(vic.ba_low_cycles(), 1);
        assert_eq!(vic.vc(), 0x0120);
        assert_eq!(vic.vmli(), 0);
        assert_eq!(vic.screen_row[0], 0xFF);
        assert_eq!(vic.colour_row[0], 0x0A);
        assert_eq!(vic.screen_row[1], 0x00);

        // Cycles 17 and 18 remain in the three-cycle BA wind-down interval.
        // Distinct inputs prove that the nibble is supplied through the bus
        // contract rather than hard-coded for one test program.
        tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
        assert_eq!(vic.vc(), 0x0121);
        assert_eq!(vic.vmli(), 1);
        assert_eq!(vic.screen_row[1], 0xFF);
        assert_eq!(vic.colour_row[1], 0x05);
        assert_eq!(vic.ba_low_cycles(), 2);
        assert!(!vic.aec_is_low());

        tick_vic_with_cpu_data(&mut vic, &memory, 0xC3);
        assert_eq!(vic.vc(), 0x0122);
        assert_eq!(vic.vmli(), 2);
        assert_eq!(vic.screen_row[2], 0xFF);
        assert_eq!(vic.colour_row[2], 0x03);
        assert_eq!(vic.ba_low_cycles(), 3);
        assert!(!vic.aec_is_low());

        // Cycle 19 is the fourth consecutive BA-low cycle. AEC is now low and
        // the first real matrix/colour read fills slot three.
        tick_vic_with_cpu_data(&mut vic, &memory, 0x77);
        assert_eq!(vic.vc(), 0x0123);
        assert_eq!(vic.vmli(), 3);
        assert_eq!(vic.screen_row[3], 0x43);
        assert_eq!(vic.colour_row[3], 0x0D);
        assert_eq!(vic.ba_low_cycles(), 4);
        assert!(vic.aec_is_low());
    }

    #[test]
    fn cycle_54_d011_write_leaves_one_late_badline_access() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 55;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.regs[0x11] = 0x11; // line $30 is not bad at YSCROLL 1
        vic.is_badline = false;

        // The CPU writes in cycle 54, before that cycle's Phi2 matrix fetch
        // (VICE stores at 54 in `sequencer-bug`). This engine makes that one
        // remaining access on the following tick.
        vic.write(0x11, 0x10);
        assert_eq!(vic.pending_d011_write_cycle(), Some(54));
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert!(vic.is_badline());
        assert!(vic.uses_late_badline_window());
        assert_eq!(vic.late_badline_fetches_remaining(), Some(0));
        assert!(vic.badline_ba_is_low());
        assert!(vic.c_access_is_active());
        assert_eq!(vic.screen_row[0], 0xFF);
        assert_eq!(vic.colour_row[0], 0x0A);
        assert_eq!(vic.vmli(), 0);
        assert_eq!(vic.forced_badline_output_delay(), 2);
        assert!(vic.forced_badline_cdata_carry_pending());
        assert_eq!(vic.forced_badline_cdata_destination_vmli(), Some(0));
        assert_eq!(
            vic.forced_badline_cdata_eligibility_cycles_remaining(),
            Some(40)
        );

        // A second attempt would exceed the window. A line created in cycle 54
        // has no further c-access or badline BA source.
        tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
        assert!(vic.is_badline());
        assert!(!vic.badline_ba_is_low());
        assert!(!vic.c_access_is_active());
        assert_eq!(vic.late_badline_fetches_remaining(), Some(0));
        assert_eq!(vic.screen_row[1], 0x00);
        assert_eq!(vic.forced_badline_output_delay(), 1);

        tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
        assert_eq!(vic.forced_badline_output_delay(), 0);

        while vic.raster_cycle != 0 {
            tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
        }
        assert!(!vic.uses_late_badline_window());
        assert_eq!(vic.late_badline_fetches_remaining(), None);
    }

    #[test]
    fn cycle_55_d011_write_has_no_late_badline_access() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 56;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.regs[0x11] = 0x11; // line $30 is not bad at YSCROLL 1
        vic.is_badline = false;

        vic.write(0x11, 0x10);
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert!(vic.is_badline());
        assert!(vic.uses_late_badline_window());
        assert_eq!(vic.late_badline_fetches_remaining(), Some(0));
        assert!(!vic.badline_ba_is_low());
        assert!(!vic.c_access_is_active());
        assert_eq!(vic.screen_row[0], 0x00);
        assert_eq!(vic.forced_badline_output_delay(), 2);
    }

    #[test]
    fn forced_badline_hidden_cells_fall_behind_the_right_border() {
        let chargen = vec![0u8; 4096];
        let mut memory = TestMemory::new(&chargen);
        memory.ram_write(0x0900, 0xFF); // bitmap byte at VC $120, RC 0
        memory.ram_write(0x0908, 0xFF); // bitmap byte at VC $121, RC 0

        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0x30;
        vic.raster_cycle = 55;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.regs[0x11] = 0x31; // BMM; line $30 is not bad at YSCROLL 1
        vic.regs[0x16] = 0x08; // 40 columns: right border closes at cycle 56
        vic.regs[0x21] = 0x06;
        vic.border_vert_ff = false;
        vic.border_main_ff = false;

        vic.write(0x11, 0x30);
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert_eq!(vic.forced_badline_output_delay(), 2);

        // A write in cycle 54 is the latest that still creates the late
        // badline, so the two hidden cells are cycles 56 and 57: behind the
        // right border, which closes at cycle 56 with 40 columns.
        for (cycle, remaining) in [(56u8, 1u8), (57, 0)] {
            tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
            assert_eq!(vic.forced_badline_output_delay(), remaining);
            let fb_y = usize::from(vic.raster_line - FIRST_VISIBLE_LINE);
            let fb_x = usize::from(cycle - FIRST_VISIBLE_CYCLE) * 8;
            for px in 0..8 {
                assert_eq!(
                    fb_pixel(&vic, fb_x + px, fb_y),
                    PALETTE[usize::from(vic.regs[0x20] & 0x0F)],
                    "cycle {cycle} pixel {px} is border"
                );
            }
        }
    }

    #[test]
    fn far_edge_output_delay_suppresses_the_last_g_access() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 55;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.regs[0x11] = 0x11;
        vic.is_badline = false;

        vic.write(0x11, 0x10);
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert_eq!((vic.vc(), vic.vmli()), (0x0120, 0));
        assert_eq!(vic.forced_badline_output_delay(), 2);

        // The far-edge write is in cycle 54, so the suppressed g-access is
        // the line's last (cycle 55). Cycles 56 and 57 make none, and the
        // counters stay put until the next line's cycle 14.
        tick_vic(&mut vic, &memory);
        assert_eq!((vic.vc(), vic.vmli()), (0x0120, 0));
        assert_eq!(vic.forced_badline_output_delay(), 1);

        tick_vic(&mut vic, &memory);
        assert_eq!((vic.vc(), vic.vmli()), (0x0120, 0));
        assert_eq!(vic.forced_badline_output_delay(), 0);
    }

    #[test]
    fn earlier_forced_badline_does_not_use_far_edge_output_delay() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 16;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.idle_state = true;
        vic.regs[0x11] = 0x11;
        vic.is_badline = false;

        vic.write(0x11, 0x10);
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert!(!vic.uses_late_badline_window());
        assert_eq!(vic.forced_badline_output_delay(), 0);

        tick_vic_with_cpu_data(&mut vic, &memory, 0x95);
        assert_eq!((vic.vc(), vic.vmli()), (0x0121, 1));
    }

    #[test]
    fn far_edge_cdata_carry_uses_the_hoxs_12_bit_merge_network() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 55;
        vic.den_latch = true;
        vic.vc = 0x0120;
        vic.vmli = 0;
        vic.rc = 7;
        vic.idle_state = true;
        vic.regs[0x11] = 0x11;
        vic.is_badline = false;

        vic.write(0x11, 0x10);
        tick_vic_with_cpu_data(&mut vic, &memory, 0x8A);
        assert_eq!(vic.screen_row[0], 0xFF);
        assert_eq!(vic.colour_row[0], 0x0A);
        assert!(vic.forced_badline_cdata_carry_pending());

        advance_until(&mut vic, &memory, 0x31, DISPLAY_START_CYCLE);
        assert_eq!(vic.rc(), 0);
        assert!(!vic.is_badline());
        assert!(vic.forced_badline_cdata_carry_pending());
        assert_eq!(vic.forced_badline_cdata_carry_age(), Some(23));
        assert_eq!(vic.forced_badline_cdata_carry_value(), Some(0));

        // First merge vector: elapsed=22, i0=21, i1=0, i2=22.
        vic.set_packed_cdata(21, 0xA62);
        vic.set_packed_cdata(0, 0x0FF);
        vic.set_packed_cdata(22, 0x153);

        tick_vic(&mut vic, &memory);
        assert_eq!(vic.packed_cdata(0), 0x173);
        assert_eq!(vic.packed_cdata(22), 0x173);
        assert_eq!(vic.forced_badline_cdata_carry_value(), Some(0x822));

        // Next merge is carry-dependent: discarding 0x822 would produce 0x0A1
        // instead of the expected 0x8A1.
        vic.set_packed_cdata(1, 0x2A5);
        vic.set_packed_cdata(23, 0x8E1);
        tick_vic(&mut vic, &memory);
        assert_eq!(vic.packed_cdata(1), 0x8A1);
        assert_eq!(vic.packed_cdata(23), 0x8A1);
        assert_eq!(vic.forced_badline_cdata_carry_value(), Some(0x822));
    }

    #[test]
    fn a_new_far_edge_badline_restarts_the_cdata_carry_origin() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.vmli = 3;
        vic.cpu_stalled = false;
        vic.late_badline_fetches_remaining = Some(1);
        vic.forced_badline_cdata_carry = Some(ForcedBadlineCdataCarry {
            age: 17,
            carry: 0x0822,
        });

        vic.c_access(&memory, 0x8A);

        assert_eq!(vic.forced_badline_cdata_carry_age(), Some(0));
        assert_eq!(vic.forced_badline_cdata_carry_value(), Some(0));
        assert_eq!(vic.forced_badline_cdata_destination_vmli(), Some(3));
    }

    #[test]
    fn ordinary_badline_fetches_slot_zero_then_advances_before_slot_one() {
        let chargen = vec![0u8; 4096];
        let mut colours = vec![0u8; 1024];
        colours[0x0200] = 0x05;
        colours[0x0201] = 0x06;
        let mut memory = TestMemory::with_colour(&chargen, colours);
        memory.ram_write(0x0200, 0x52);
        memory.ram_write(0x0201, 0x63);

        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0x30;
        vic.raster_cycle = 12;
        vic.den_latch = true;
        vic.write(0x11, 0x10);
        vic.vcbase = 0x0200;
        vic.vc = 0x0200;
        vic.vmli = 0;
        vic.idle_state = false;
        vic.is_badline = true;
        assert_eq!(vic.late_badline_fetches_remaining(), None);

        for expected_age in 1..=3 {
            tick_vic(&mut vic, &memory);
            assert_eq!(vic.ba_low_cycles(), expected_age);
            assert!(!vic.aec_is_low());
        }
        assert_eq!(vic.raster_cycle(), 15);

        tick_vic(&mut vic, &memory);
        assert!(vic.aec_is_low());
        assert_eq!(vic.vc(), 0x0200);
        assert_eq!(vic.vmli(), 0);
        assert_eq!(vic.screen_row[0], 0x52);
        assert_eq!(vic.colour_row[0], 0x05);

        tick_vic(&mut vic, &memory);
        assert_eq!(vic.vc(), 0x0201);
        assert_eq!(vic.vmli(), 1);
        assert_eq!(vic.screen_row[1], 0x63);
        assert_eq!(vic.colour_row[1], 0x06);
    }

    #[test]
    fn continuous_ba_across_badline_and_sprite_dma_keeps_aec_low() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = 54;
        vic.den_latch = true;
        vic.is_badline = true;
        vic.idle_state = false;
        vic.ba_low = true;
        vic.ba_low_cycles = 3;
        vic.write(0x11, 0x10); // keep line $30 bad
        vic.write(0x15, 0x01); // sprite 0 enabled
        vic.write(0x01, 0x30); // sprite 0 DMA-active on this line

        tick_vic(&mut vic, &memory); // final badline BA cycle
        assert!(vic.aec_is_low());
        assert_eq!(vic.ba_low_cycles(), 4);

        tick_vic(&mut vic, &memory); // sprite BA begins without a high gap
        assert!(vic.ba_low);
        assert!(vic.aec_is_low());
        assert_eq!(vic.ba_low_cycles(), 4);
    }

    #[test]
    fn opened_side_border_shows_the_last_characters_ecm_background() {
        // ECM text whose every matrix entry selects `$D024` (bits 7-6 = 3).
        // Switching to 38 columns after cycle 56's border check skips the
        // 38-column check, so the side border stays open. Beyond the fetch
        // window the sequencer shifts out zero bits with the last matrix
        // entry, so the opened border shows `$D024`, not `$D021`.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x5B);
        vic.write(0x16, 0x08);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x06);
        vic.write(0x24, 0x02);

        let target_line = DISPLAY_START_LINE + 4;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        vic.screen_row = [0xC0; 40];
        step_cycles(&mut vic, &memory, 41);
        vic.write(0x16, 0x00);
        step_cycles(&mut vic, &memory, 4);

        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x = usize::from(DISPLAY_END_CYCLE - FIRST_VISIBLE_CYCLE) * 8;
        let frame = settled(&vic);
        let row = &frame.framebuffer()[fb_y * FB_WIDTH as usize..];
        assert_eq!(&row[fb_x..fb_x + 24], &[PALETTE[2]; 24]);
    }

    #[test]
    fn vertical_border_keeps_the_last_matrix_entries() {
        // Below the display window, with the vertical border set but the
        // side border open, the display column shows the sequencer's zero
        // bits. In hires bitmap mode they take the low nybble of the last
        // matrix entry, which idle lines leave at zero: black, not `$D021`.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x3B);
        vic.write(0x16, 0x08);
        vic.write(0x21, 0x06);
        vic.raster_line = 0xFA;
        vic.raster_cycle = 30;
        vic.idle_state = true;
        vic.border_vert_ff = true;
        vic.display_border = false;
        vic.display_border_history = [false; 2];
        vic.last_matrix_entries = (0x00, 0x00);

        step_cycles(&mut vic, &memory, 4);
        let fb_x = usize::from(32 - FIRST_VISIBLE_CYCLE) * 8;
        let offset = 0xFA * FB_WIDTH as usize + fb_x;
        assert_eq!(
            &settled(&vic).framebuffer[offset..offset + 8],
            &[PALETTE[0]; 8]
        );
    }

    #[test]
    fn open_vertical_border_replaces_stale_pixels_with_idle_background() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.raster_line = 0x30;
        vic.raster_cycle = DISPLAY_START_CYCLE;
        vic.den_latch = true;
        vic.border_vert_ff = false;
        vic.border_main_ff = false;
        vic.idle_state = true;
        vic.write(0x11, 0x11); // non-bad YSCROLL phase
        vic.write(0x16, 0x08); // CSEL: clear main FF at cycle 16
        vic.write(0x20, 0x0E); // stale border colour
        vic.write(0x21, 0x00); // idle/background colour

        let fb_y = 0x30usize;
        let fb_x = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        let offset = fb_y * FB_WIDTH as usize + fb_x;
        vic.framebuffer[offset..offset + 8].fill(PALETTE[0x0E]);

        tick_vic(&mut vic, &memory);
        assert_eq!(
            &settled(&vic).framebuffer[offset..offset + 8],
            &[PALETTE[0]; 8],
            "an open vertical border must expose freshly generated idle pixels"
        );
    }

    #[test]
    fn open_vertical_border_exposes_live_display_cell() {
        let chargen = vec![0xFFu8; 4096];
        let memory = TestMemory::new(&chargen);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0x30;
        vic.raster_cycle = DISPLAY_START_CYCLE + 1;
        vic.den_latch = true;
        vic.border_vert_ff = false;
        vic.border_main_ff = false;
        vic.idle_state = false;
        vic.vmli = 0;
        vic.screen_row[0] = 0;
        vic.colour_row[0] = 0x0C;
        vic.write(0x11, 0x11); // standard text, non-bad YSCROLL phase
        vic.write(0x16, 0x08);
        vic.write(0x18, 0x04); // character data at $1000

        let fb_y = 0x30usize;
        let fb_x = (DISPLAY_START_CYCLE + 1 - FIRST_VISIBLE_CYCLE) as usize * 8;
        let offset = fb_y * FB_WIDTH as usize + fb_x;
        tick_vic(&mut vic, &memory);
        assert_eq!(
            &settled(&vic).framebuffer[offset..offset + 8],
            &[PALETTE[0x0C]; 8],
            "an open vertical border must reveal the active display pipeline"
        );
    }

    #[test]
    fn open_vertical_border_exposes_idle_bitmap_fetch() {
        let chargen = vec![0u8; 4096];
        let mut memory = TestMemory::new(&chargen);
        memory.ram_write(0x3FFF, 0x80);

        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0xF9;
        // Start a cycle early: the sequencer reads the mode bits for a
        // cell's first dots from the cycle before.
        vic.raster_cycle = DISPLAY_START_CYCLE;
        vic.den_latch = true;
        vic.border_vert_ff = false;
        vic.border_main_ff = false;
        vic.idle_state = true;
        vic.write(0x11, 0x31); // DEN + hires bitmap mode
        vic.write(0x16, 0x08);
        vic.write(0x21, 0x06); // distinguish background fill from idle output

        let fb_y = 0xF9usize;
        let fb_x = (DISPLAY_START_CYCLE + 1 - FIRST_VISIBLE_CYCLE) as usize * 8;
        let offset = fb_y * FB_WIDTH as usize + fb_x;
        tick_vic(&mut vic, &memory);
        tick_vic(&mut vic, &memory);
        assert_eq!(
            &settled(&vic).framebuffer[offset..offset + 8],
            &[PALETTE[0]; 8],
            "idle bitmap fetches use zeroed video-matrix colours, not D021"
        );
    }

    #[test]
    fn idle_multicolour_bitmap_keeps_d021_for_zero_pairs() {
        let chargen = vec![0u8; 4096];
        let mut memory = TestMemory::new(&chargen);
        memory.ram_write(0x3FFF, 0b00_01_10_11);

        let mut vic = Vic::new(VicModel::Pal6569);
        vic.raster_line = 0xF9;
        // Start a cycle early: the sequencer reads the mode bits for a
        // cell's first dots from the cycle before.
        vic.raster_cycle = DISPLAY_START_CYCLE;
        vic.den_latch = true;
        vic.border_vert_ff = false;
        vic.border_main_ff = false;
        vic.idle_state = true;
        vic.write(0x11, 0x31); // DEN + bitmap mode
        vic.write(0x16, 0x18); // CSEL + multicolour mode
        vic.write(0x21, 0x06);

        let fb_y = 0xF9usize;
        let fb_x = (DISPLAY_START_CYCLE + 1 - FIRST_VISIBLE_CYCLE) as usize * 8;
        let offset = fb_y * FB_WIDTH as usize + fb_x;
        tick_vic(&mut vic, &memory);
        tick_vic(&mut vic, &memory);
        assert_eq!(
            &settled(&vic).framebuffer[offset..offset + 8],
            &[
                PALETTE[6], PALETTE[6], PALETTE[0], PALETTE[0], PALETTE[0], PALETTE[0], PALETTE[0],
                PALETTE[0],
            ],
            "multicolour bitmap idle data maps 00 to D021 and 01/10/11 to black"
        );
    }

    #[test]
    fn final_composite_resolves_all_colour_register_sources() {
        let (mut vic, _) = make_vic_and_memory();
        for register in 0x20u8..=0x2E {
            vic.regs[usize::from(register)] = 0x05;
            assert_eq!(vic.resolve_colour_index(register), 5);
        }
        assert_eq!(vic.resolve_colour_index(0x07), 7);
    }

    /// Write `register` = `value` between two ticks in the top border, then
    /// return the eight dots of the cell the next tick resolves.
    fn border_cell_after_colour_write(model: VicModel, register: u8, value: u8) -> [u32; 8] {
        let (mut vic, memory) = make_vic_and_memory_model(model);
        vic.regs[0x20] = 0x02;
        vic.regs[0x21] = 0x06;
        advance_until(&mut vic, &memory, 10, 30);
        vic.write(register, value);
        let cell = vic.colour_stage[0].expect("a cell is waiting in the colour stage");
        tick_vic(&mut vic, &memory);
        let mut dots = [0; 8];
        dots.copy_from_slice(&vic.framebuffer[cell.fb_offset..cell.fb_offset + 8]);
        for (dot, &rgb) in dots.iter().enumerate() {
            assert_eq!(
                PALETTE[usize::from(vic.signal_codes[cell.fb_offset + dot])],
                rgb,
                "electrical colour must retain the final {model:?} dot {dot}"
            );
        }
        dots
    }

    #[test]
    fn colour_write_first_dot_follows_the_chip_revision() {
        let mut nmos = [PALETTE[5]; 8];
        nmos[0] = PALETTE[2];
        let mut hmos = [PALETTE[5]; 8];
        hmos[0] = PALETTE[0x0F];
        for (model, expected) in [
            (VicModel::Pal6569, nmos),
            (VicModel::Ntsc6567, nmos),
            (VicModel::Ntsc6567R56A, nmos),
            (VicModel::Pal8565, hmos),
            (VicModel::Ntsc8562, hmos),
        ] {
            assert_eq!(
                border_cell_after_colour_write(model, 0x20, 0x05),
                expected,
                "{model:?}: the 6567/6569 keep the old colour on dot 0, the 8562/8565 show grey"
            );
        }
    }

    #[test]
    fn grey_dot_needs_the_written_register_not_a_new_value() {
        // Rewriting the border's own colour still shows the grey dot.
        let mut same = [PALETTE[2]; 8];
        same[0] = PALETTE[0x0F];
        assert_eq!(
            border_cell_after_colour_write(VicModel::Pal8565, 0x20, 0x02),
            same
        );
        // The border is chosen before the colour registers are resolved, so
        // a write to the background register leaves a border dot alone.
        assert_eq!(
            border_cell_after_colour_write(VicModel::Pal8565, 0x21, 0x05),
            [PALETTE[2]; 8]
        );
    }

    #[test]
    fn hmos_models_share_their_nmos_timing() {
        for (hmos, nmos) in [
            (VicModel::Pal8565, VicModel::Pal6569),
            (VicModel::Ntsc8562, VicModel::Ntsc6567),
        ] {
            assert_eq!(hmos.lines_per_frame(), nmos.lines_per_frame());
            assert_eq!(hmos.cycles_per_line(), nmos.cycles_per_line());
            assert_eq!(hmos.sprite_timing().paccess, nmos.sprite_timing().paccess);
            assert!(hmos.has_grey_dot() && !nmos.has_grey_dot());
            assert_eq!(Vic::new(hmos).model(), hmos);
        }
    }

    // ----- Cov-5c wave 2: directed coverage tests -----

    #[test]
    fn vic_model_ntsc_timings() {
        assert_eq!(VicModel::Ntsc6567.lines_per_frame(), 263);
        assert_eq!(VicModel::Ntsc6567.cycles_per_line(), 65);
        assert_eq!(VicModel::Pal6569.lines_per_frame(), 312);
        assert_eq!(VicModel::Pal6569.cycles_per_line(), 63);
    }

    #[test]
    fn vic_model_default_is_pal() {
        assert_eq!(VicModel::default(), VicModel::Pal6569);
    }

    #[test]
    fn ntsc_sprite_schedule_matches_6567r8() {
        // VICE cycle_tab_ntsc SprPtr cycles (engine 0-based): sprites 0-3 in
        // the previous line's tail (59/61/63/0-wrap), 4-7 on the current line
        // (2/4/6/8); DMA/display checks shift +1 vs PAL.
        let t = VicModel::Ntsc6567.sprite_timing();
        assert_eq!(
            t.paccess,
            [
                (59, true),
                (61, true),
                (63, true),
                (0, true),
                (2, false),
                (4, false),
                (6, false),
                (8, false),
            ]
        );
        assert_eq!(t.chk_dma, [56, 57]);
        assert_eq!(t.chk_exp, 56);
        assert_eq!(t.chk_disp, 59);
    }

    #[test]
    fn ntsc_sprite_access_cycles_resolve_per_model() {
        let ntsc = Vic::new(VicModel::Ntsc6567);
        // Sprite 0 p-access at 59 (NTSC) not 58 (PAL); s-access the next cycle.
        assert_eq!(ntsc.sprite_paccess_cycle(59), Some((0, true)));
        assert_eq!(ntsc.sprite_saccess_cycle(60), Some(0));
        // Sprite 3 straddles the line boundary (p-access at 0, s-access at 1).
        assert_eq!(ntsc.sprite_paccess_cycle(0), Some((3, true)));
        assert_eq!(ntsc.sprite_saccess_cycle(1), Some(3));
        // Sprite 4 is first on the current line at cycle 2.
        assert_eq!(ntsc.sprite_paccess_cycle(2), Some((4, false)));
        // The PAL sprite-0 cycle (58) is not a p-access on NTSC.
        assert_eq!(ntsc.sprite_paccess_cycle(58), None);

        let pal = Vic::new(VicModel::Pal6569);
        assert_eq!(pal.sprite_paccess_cycle(58), Some((0, true)));
        assert_eq!(pal.sprite_paccess_cycle(59), None);
    }

    #[test]
    fn ntsc_r56a_timings_and_schedule() {
        assert_eq!(VicModel::Ntsc6567R56A.lines_per_frame(), 262);
        assert_eq!(VicModel::Ntsc6567R56A.cycles_per_line(), 64);
        let t = VicModel::Ntsc6567R56A.sprite_timing();
        // Between PAL and R8: sprites 0-2 at 59/61/63 (PAL 58/60/62), but
        // sprite 3 stays on the current line at cycle 1 (R8 wraps it to 0).
        assert_eq!(t.paccess[0], (59, true));
        assert_eq!(t.paccess[2], (63, true));
        assert_eq!(t.paccess[3], (1, false));
        assert_eq!(t.chk_dma, [56, 57]); // like R8
        assert_eq!(t.chk_disp, 58); // like PAL

        let vic = Vic::new(VicModel::Ntsc6567R56A);
        assert_eq!(vic.sprite_paccess_cycle(59), Some((0, true)));
        assert_eq!(vic.sprite_paccess_cycle(1), Some((3, false)));
        // Sprite 2's s-access wraps to engine cycle 0 (VICE cycle 64).
        assert_eq!(vic.sprite_saccess_cycle(0), Some(2));
    }

    #[test]
    fn ntsc_sprite_dma_steals_at_ntsc_cycles() {
        // Enable sprite 0 at a Y that is DMA-active on line 60, then confirm it
        // steals the bus on its NTSC p-access (59) + s-access (60), not the PAL
        // cycle 58.
        let (mut vic, memory) = make_vic_and_memory_model(VicModel::Ntsc6567);
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x01, 60); // sprite 0 Y = 60
        // Wind just past line 60 cycle 56 (NTSC ChkSprDma[0], processed at the
        // end of that cycle's tick) so DMA is evaluated.
        advance_until(&mut vic, &memory, 60, 57);
        assert!(vic.chain.dma_active(0), "sprite 0 should be DMA-active");
        // Cycle 58 is a steal on PAL but not NTSC (checked before 59, forward).
        advance_until(&mut vic, &memory, 60, 58);
        assert!(
            !vic.is_sprite_dma_stealing(),
            "cyc 58 is not a steal on NTSC (it is on PAL)"
        );
        advance_until(&mut vic, &memory, 60, 59);
        assert!(
            vic.is_sprite_dma_stealing(),
            "steal on NTSC p-access cyc 59"
        );
    }

    #[test]
    fn ntsc_construction_uses_ntsc_visible_lines() {
        let vic = Vic::new(VicModel::Ntsc6567);
        // NTSC renders the full frame (0..263), like PAL — 263 lines.
        assert_eq!(vic.framebuffer_height(), 263);
    }

    #[test]
    fn default_constructs_pal_vic() {
        let vic: Vic = Vic::default();
        assert_eq!(vic.framebuffer_width(), FB_WIDTH);
        // PAL fb height: 312 - 0 = 312.
        assert_eq!(vic.framebuffer_height(), 312);
    }

    #[test]
    fn public_accessor_methods_round_trip() {
        let mut vic = Vic::new(VicModel::Pal6569);
        // Direct accessors initially zero.
        assert_eq!(vic.char_row(), 0);
        assert!(!vic.is_badline());
        assert!(!vic.ba_is_low());
        // registers() returns the raw register file pointer.
        let regs_snapshot = *vic.registers();
        assert_eq!(regs_snapshot.len(), 0x40);
        // irq_status getter/setter round-trip.
        vic.set_irq_status(0x0F);
        assert_eq!(vic.irq_status(), 0x0F);
        // set_registers should restore both raster_compare and irq_enable.
        let mut new_regs = [0u8; 0x40];
        new_regs[0x11] = 0x80; // raster compare bit 8 set
        new_regs[0x12] = 0x10;
        new_regs[0x1A] = 0x01;
        vic.set_registers(&new_regs);
        // peek($D011) reports raster bit 8 in bit 7. At reset the CPU still
        // sees the frame's last line, 311, until line 0 begins on cycle 2.
        assert_eq!(vic.peek(0x11) & 0x80, 0x80);
        // The raw register bits read back via registers().
        assert_eq!(vic.registers()[0x11], 0x80);
        assert_eq!(vic.registers()[0x12], 0x10);
        // raster_compare = ($D011 bit 7) << 8 | $D012 = 0x110 = 272.
        // PAL has 312 lines, so 272 is reachable.
        vic.set_irq_status(0);
        let memory = TestMemory::new(&[0u8; 4096]);
        let mut hit = false;
        for _ in 0..(63u32 * 400) {
            tick_vic(&mut vic, &memory);
            if (vic.irq_status() & 0x01) != 0 {
                hit = true;
                break;
            }
        }
        assert!(hit, "raster IRQ never latched at compare 0x110");
        assert_eq!(vic.raster_line(), 0x110);
    }

    #[test]
    fn read_d011_returns_high_bit_of_raster_line() {
        let (mut vic, memory) = make_vic_and_memory();
        // Advance to a line >= 256. PAL has 312 lines; line 256 is reachable.
        advance_until(&mut vic, &memory, 256, 3);
        // Set CR1 lower bits (mode/yscroll) to a known non-zero pattern.
        vic.write(0x11, 0x1B);
        let v = vic.read(0x11);
        // Bit 7 should be set since raster_line >= 256.
        assert_eq!(v & 0x80, 0x80);
        // Lower bits preserved.
        assert_eq!(v & 0x7F, 0x1B);
    }

    #[test]
    fn read_d012_returns_low_byte_of_raster_line() {
        let (mut vic, memory) = make_vic_and_memory();
        // Advance past the CPU-visible edge of line 5.
        advance_until(&mut vic, &memory, 5, 3);
        assert_eq!(vic.read(0x12), 5);
    }

    #[test]
    fn read_d019_composite_irq_bit_and_unused_high_bits() {
        let mut vic = Vic::new(VicModel::Pal6569);
        // Force raster IRQ pending, with mask enabled.
        vic.set_irq_status(0x01);
        vic.write(0x1A, 0x01);
        let v = vic.read(0x19);
        // Bit 7 = composite, bits 6:4 = 1, bit 0 = pending raster IRQ.
        assert_eq!(v & 0x80, 0x80);
        assert_eq!(v & 0x70, 0x70);
        assert_eq!(v & 0x01, 0x01);
        // With no enable, bit 7 should clear but the latched bit stays.
        vic.write(0x1A, 0x00);
        let v2 = vic.read(0x19);
        assert_eq!(v2 & 0x80, 0x00);
        assert_eq!(v2 & 0x01, 0x01);
    }

    #[test]
    fn read_d01a_returns_irq_enable_with_high_nibble_set() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x1A, 0x05);
        assert_eq!(vic.read(0x1A), 0xF5);
    }

    #[test]
    fn write_d019_acknowledges_only_set_bits() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.set_irq_status(0x0F);
        vic.write(0x19, 0x05); // ack bits 0 and 2 only
        assert_eq!(vic.peek(0x19) & 0x0F, 0x0A);
    }

    #[test]
    fn peek_d011_d012_match_raster() {
        let (mut vic, memory) = make_vic_and_memory();
        advance_until(&mut vic, &memory, 257, 3);
        vic.write(0x11, 0x13);
        // peek($D011) should report raster bit 8 in bit 7 of the result.
        assert_eq!(vic.peek(0x11) & 0x80, 0x80);
        assert_eq!(vic.peek(0x12), (vic.cpu_visible_raster_line() & 0xFF) as u8);
    }

    #[test]
    fn peek_d019_returns_irq_status_and_composite() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.set_irq_status(0x02);
        vic.write(0x1A, 0x02);
        let v = vic.peek(0x19);
        assert_eq!(v & 0x80, 0x80);
        assert_eq!(v & 0x02, 0x02);
        // Without enable, composite bit clears.
        vic.write(0x1A, 0x00);
        assert_eq!(vic.peek(0x19) & 0x80, 0x00);
    }

    #[test]
    fn peek_d01a_returns_raw_enable() {
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x1A, 0x09);
        assert_eq!(vic.peek(0x1A), 0x09);
    }

    #[test]
    fn peek_returns_register_for_other_addrs_and_last_bus_above_2e() {
        let (mut vic, memory) = make_vic_and_memory();
        for _ in 0..(CYCLES_PER_LINE as u32 * (DISPLAY_START_LINE as u32 + 2)) {
            tick_vic(&mut vic, &memory);
        }
        vic.write(0x20, 0x05);
        // peek of a colour reg returns the raw register without high-nibble mask.
        assert_eq!(vic.peek(0x20), 0x05);
        // peek($D02F..$D03F) returns last_bus_data.
        let lb = vic.peek(0x2F);
        assert_eq!(vic.peek(0x30), lb);
        assert_eq!(vic.peek(0x3F), lb);
    }

    #[test]
    fn ba_is_low_reflects_pin_state() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // DEN=1, RSEL=1, YSCROLL=3
        advance_to(&mut vic, &memory, 0x33, 0);
        // Run until we are inside the badline-stealing window.
        for _ in 0..20 {
            tick_vic(&mut vic, &memory);
        }
        assert_eq!(vic.ba_is_low(), vic.ba_low);
    }

    #[test]
    fn is_badline_accessor_reports_badline_state() {
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x11, 0x1B); // DEN=1, YSCROLL=3
        // Walk until we see a badline.
        let mut saw_badline = false;
        for _ in 0..(CYCLES_PER_LINE as u32 * 100) {
            tick_vic(&mut vic, &memory);
            if vic.is_badline() {
                saw_badline = true;
                break;
            }
        }
        assert!(saw_badline);
    }

    #[test]
    fn hires_bitmap_renders_fg_and_bg_from_screen_byte() {
        // BMM=1, MCM=0 → render_hires_bitmap. Bitmap byte 0xF0 paints
        // 4 fg + 4 bg pixels. fg = upper nibble of screen byte, bg = lower.
        let chargen = vec![0u8; 4096];
        let mut memory = TestMemory::new(&chargen);
        let mut vic = Vic::new(VicModel::Pal6569);
        // BMM=1, DEN=1, RSEL=1, YSCROLL=3 → 0x3B
        vic.write(0x11, 0x3B);
        // CB=0 (bitmap at 0x0000), VM=0x14 → screen at 0x1000.
        vic.write(0x18, 0x14);
        // CSEL=1 so the main FF clears at cycle 16 (matches DISPLAY_START_CYCLE).
        vic.write(0x16, 0x08);
        let target_line = DISPLAY_START_LINE + 3;
        // bitmap_addr = bitmap_base + VC*8 + RC. VC=0 (column 0 of row 0),
        // RC=0 (badline row) → addr 0.
        memory.ram_write(0, 0xF0);
        // Screen base = (0x14 >> 4) * 0x400 = 0x400. Column 0 → addr 0x400.
        memory.ram_write(0x400, 0x52); // fg=palette[5], bg=palette[2]
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        // First 4 px = fg (bit set), last 4 px = bg (bit clear).
        for px in 0..4 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[5]);
        }
        for px in 4..8 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[2]);
        }
    }

    #[test]
    fn mcm_bitmap_renders_four_pixel_pairs() {
        // BMM=1, MCM=1. Pairs in bitmap byte select bg0 / c01 / c10 / c11.
        let chargen = vec![0u8; 4096];
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x07; // colour_nybble for col 0 = 7 → c11
            v
        };
        let mut memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        // BMM=1, MCM=1, DEN=1 → CR1=0x3B, CR2=0x18 (CSEL+MCM).
        vic.write(0x11, 0x3B);
        vic.write(0x16, 0x18);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x02); // bg0 = 2
        // Bitmap at 0x0000, bytes=0b00_01_10_11 = 0x1B → pair colours (bg0, c01, c10, c11).
        let target_line = DISPLAY_START_LINE + 3;
        // VC=0, RC=0 on the badline row → bitmap addr 0.
        memory.ram_write(0, 0x1B);
        // Screen base = 0x400. Column 0 → addr 0x400.
        memory.ram_write(0x400, 0x46); // c01=palette[4], c10=palette[6]
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        // Pair 0 = bg0 (palette[2]).
        assert_eq!(fb_pixel(&vic, fb_x0, fb_y), PALETTE[2]);
        assert_eq!(fb_pixel(&vic, fb_x0 + 1, fb_y), PALETTE[2]);
        // Pair 1 = c01 (palette[4]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 2, fb_y), PALETTE[4]);
        assert_eq!(fb_pixel(&vic, fb_x0 + 3, fb_y), PALETTE[4]);
        // Pair 2 = c10 (palette[6]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 4, fb_y), PALETTE[6]);
        assert_eq!(fb_pixel(&vic, fb_x0 + 5, fb_y), PALETTE[6]);
        // Pair 3 = c11 (palette[7]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 6, fb_y), PALETTE[7]);
        assert_eq!(fb_pixel(&vic, fb_x0 + 7, fb_y), PALETTE[7]);
    }

    #[test]
    fn mcm_text_with_high_colour_bit_renders_multicolour() {
        // MCM=1 + colour bit 3 set → render_mcm_text full path.
        let chargen = vec![0xB4u8; 4096]; // 0b10110100 → pairs 10 11 01 00
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x0F; // colour bit 3 set → MCM enable, fg = palette[7]
            v
        };
        let memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        // MCM=1 in CR2 (bit 4), CSEL=1.
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x18);
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x01); // bg0
        vic.write(0x22, 0x02); // bg1
        vic.write(0x23, 0x03); // bg2
        let target_line = DISPLAY_START_LINE + 3;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        // Pair 0 = 10 → bg2 (palette[3]).
        assert_eq!(fb_pixel(&vic, fb_x0, fb_y), PALETTE[3]);
        // Pair 1 = 11 → fg (palette[7]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 2, fb_y), PALETTE[7]);
        // Pair 2 = 01 → bg1 (palette[2]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 4, fb_y), PALETTE[2]);
        // Pair 3 = 00 → bg0 (palette[1]).
        assert_eq!(fb_pixel(&vic, fb_x0 + 6, fb_y), PALETTE[1]);
    }

    #[test]
    fn mcm_text_with_low_colour_bit_falls_back_to_standard_text() {
        // colour bit 3 clear → render_mcm_text returns render_standard_text result.
        let chargen = vec![0xFFu8; 4096];
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x07; // colour bit 3 clear
            v
        };
        let memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x18); // MCM=1 in register
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x02);
        let target_line = DISPLAY_START_LINE + 3;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        // 0xFF chargen → all foreground = palette[7].
        for px in 0..8 {
            assert_eq!(fb_pixel(&vic, fb_x0 + px, fb_y), PALETTE[7]);
        }
    }

    #[test]
    fn sprite_x_high_bit_places_sprite_past_256() {
        // Set sprite 0 X to 256 + 4 = 260 via $D010 bit 0.
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x01);
        vic.write(0x00, 4); // low byte
        vic.write(0x10, 0x01); // high bit for sprite 0
        vic.write(0x01, 100);
        vic.write(0x27, 0x05); // colour palette[5]
        vic.write(0x18, 0x14);
        vic.write(0x11, 0x1B);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        // sprite_fb_x = 260 + 24 = 284. Need a cycle that paints this fb_x.
        // fb_x = (cycle - 10) * 8. Cycle 45 paints fb_x 280..288 → covers 284.
        // Sprite Y = 100 draws at line 101 (sequencer first-activation +1).
        let target_line = 101u16;
        let target_cycle = 45u8;
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let idx = fb_y * FB_WIDTH as usize + 284;
        assert_eq!(settled(&vic).framebuffer()[idx], PALETTE[5]);
    }

    /// VICE 3.10 draw_sprites8, compiled directly from the vendored source.
    /// Both mode edges, eight X phases and expansion states: 32 dots per row.
    #[test]
    fn sprite_multicolour_transition_matches_reference_dots() {
        let reference = include_str!("../tests/fixtures/sprite-mc-dots.txt");
        let mut failures = Vec::new();
        let mut cases = 0;
        for row in reference.lines() {
            let fields: Vec<_> = row.split_whitespace().collect();
            assert_eq!(fields.len(), 5);
            let hmos = fields[0] == "1";
            let expand: u8 = fields[1].parse().expect("expansion flag");
            let initial_mc: u8 = fields[2].parse().expect("mode flag");
            let phase: u8 = fields[3].parse().expect("X phase");
            let expected: Vec<_> = fields[4].bytes().map(|b| b - b'0').collect();
            assert_eq!(expected.len(), 32);
            for model in [VicModel::Pal6569, VicModel::Ntsc6567,
                VicModel::Ntsc6567R56A, VicModel::Pal8565, VicModel::Ntsc8562] {
                if model.has_grey_dot() != hmos { continue; }
                let mut vic = Vic::new(model);
                vic.raster_cycle = 20;
                vic.regs[0x00] = 56 + phase; // framebuffer X = 80 + phase
                vic.regs[0x1c] = initial_mc;
                vic.regs[0x1d] = expand;
                vic.sprite_sequencer.set_mc_bits(initial_mc);
                vic.sprite_sequencer.set_pending(1);
                vic.sprite_sequencer.load_data(0, 0x69ad96);
                let mut actual = Vec::new();
                for cycle in 0..4 {
                    if cycle == 1 { vic.regs[0x1c] = initial_mc ^ 1; }
                    vic.run_sprite_draw_cycle();
                    actual.extend(vic.sprite_cycle_px.map(|p| p.map_or(0, |p| p.selector)));
                    vic.raster_cycle += 1;
                }
                cases += 1;
                if actual != expected {
                    failures.push(format!("{model:?} expand={expand} initial_mc={initial_mc} phase={phase}: {actual:?} != {expected:?}"));
                }
            }
        }
        assert_eq!(cases, 160);
        assert!(failures.is_empty(), "{} / {cases} dot sequences disagree:\n{}", failures.len(), failures.join("\n"));
    }

    #[test]
    fn sprite_multicolor_renders_three_colours() {
        // MCM sprite: pairs select transparent / mc0 / sprite_col / mc1.
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x1C, 0x01); // sprite 0 multicolor
        vic.write(0x00, 172);
        vic.write(0x01, 100);
        vic.write(0x25, 0x04); // mc0
        vic.write(0x26, 0x06); // mc1
        vic.write(0x27, 0x05); // sprite 0 colour
        vic.write(0x18, 0x14);
        vic.write(0x11, 0x1B);
        memory.ram_write(0x07F8, 0x80);
        // Pattern: 0b00_01_10_11 = 0x1B → pairs (transparent, mc0, sprite, mc1).
        memory.ram_write(0x2000, 0x1B);
        memory.ram_write(0x2001, 0x1B);
        memory.ram_write(0x2002, 0x1B);
        // sprite_fb_x = 172 + 24 = 196. Cycle 34 → fb_x 192..200. Cycle 35 → 200..208.
        // Sprite Y = 100 draws at line 101 (sequencer first-activation +1).
        let target_line = 101u16;
        let target_cycle = 34u8;
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let row_off = fb_y * FB_WIDTH as usize;
        // pair 0 (px 196,197): transparent → background (border colour 14 default).
        // pair 1 (px 198,199): mc0 → palette[4].
        assert_eq!(settled(&vic).framebuffer()[row_off + 198], PALETTE[4]);
        assert_eq!(settled(&vic).framebuffer()[row_off + 199], PALETTE[4]);
        // Tick another cycle to cover 200..208.
        tick_vic(&mut vic, &memory);
        // pair 2 (200,201): sprite_col palette[5].
        assert_eq!(settled(&vic).framebuffer()[row_off + 200], PALETTE[5]);
        assert_eq!(settled(&vic).framebuffer()[row_off + 201], PALETTE[5]);
        // pair 3 (202,203): mc1 palette[6].
        assert_eq!(settled(&vic).framebuffer()[row_off + 202], PALETTE[6]);
        assert_eq!(settled(&vic).framebuffer()[row_off + 203], PALETTE[6]);
    }

    #[test]
    fn sprite_priority_below_foreground_is_hidden() {
        // Sprite 0 with priority bit set ($D01B) should be hidden behind FG.
        let chargen = vec![0xFFu8; 4096];
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x01; // FG bits in column 0
            v
        };
        let mut memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x1B, 0x01); // sprite 0 BEHIND fg
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x08); // CSEL=1 so border off at left edge (cycle 16)
        vic.write(0x18, 0x14);
        vic.write(0x00, 24); // sprite_fb_x = 48 → cycle 16 paints fb_x 48..56.
        vic.write(0x01, 51);
        vic.write(0x27, 0x05);
        memory.ram_write(0x07F8, 0x80);
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        let target_line = 51u16;
        let target_cycle = DISPLAY_START_CYCLE; // cycle 16 → fb_x 48..56
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let row_off = fb_y * FB_WIDTH as usize;
        // FG is solid (0xFF chargen): sprite hidden, pixels remain text fg.
        assert_eq!(settled(&vic).framebuffer()[row_off + 48], PALETTE[1]);
    }

    #[test]
    fn sprite_dma_y_expand_extends_height() {
        // y_expand sprite (height 42) should still be DMA-active at offset 25.
        let (mut vic, memory) = make_vic_and_memory();
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x17, 0x01); // y-expand sprite 0
        vic.write(0x01, 0); // sprite Y = 0
        // Walk to line 25, cycle 55, where the sprite-DMA check runs.
        advance_to(&mut vic, &memory, 25, 55);
        tick_vic(&mut vic, &memory);
        // Without y-expand, height = 21; so offset 25 would NOT be DMA-active.
        // With y-expand, height = 42; so offset 25 IS DMA-active.
        assert!(vic.chain.dma_active(0));
    }

    #[test]
    fn sprite_y_expand_fetch_uses_halved_data_line() {
        // Build a sprite where data byte 0 differs from byte at line 1.
        // With y-expand, lines 0 and 1 should both fetch data_line=0.
        let (mut vic, mut memory) = make_vic_and_memory();
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x17, 0x01); // y-expand
        vic.write(0x00, 24); // X
        vic.write(0x01, 100); // Y
        vic.write(0x18, 0x14);
        vic.write(0x11, 0x1B);
        // 40 columns: X = 24 is the first dot inside the side border.
        vic.write(0x16, 0x08);
        vic.write(0x27, 0x05);
        memory.ram_write(0x07F8, 0x80);
        // data_line 0 (target_line - 100 == 1, /2 = 0) → bytes at 0x2000..2002.
        memory.ram_write(0x2000, 0xFF);
        memory.ram_write(0x2001, 0xFF);
        memory.ram_write(0x2002, 0xFF);
        let target_line = 101u16; // line 1 of sprite
        let target_cycle = DISPLAY_START_CYCLE; // fb_x = 48..56, sprite_fb_x = 48
        let total = u32::from(target_line) * u32::from(CYCLES_PER_LINE) + u32::from(target_cycle);
        for _ in 0..=total {
            tick_vic(&mut vic, &memory);
        }
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let row_off = fb_y * FB_WIDTH as usize;
        // Sprite present at fb_x 48 since data byte 0 = 0xFF.
        assert_eq!(settled(&vic).framebuffer()[row_off + 48], PALETTE[5]);
    }

    #[test]
    fn sprite_off_screen_below_visible_lines_is_skipped() {
        // The fetch_sprite_if_scheduled path bails when target_line is
        // outside visible lines. PAL: visible 0..312, so wrap test.
        // NTSC: visible 14..258. Use an NTSC vic and advance past line 257.
        let chargen = vec![0u8; 4096];
        let memory = TestMemory::new(&chargen);
        let mut vic = Vic::new(VicModel::Ntsc6567);
        vic.write(0x15, 0x01); // enable sprite 0
        vic.write(0x01, 0); // sprite Y = 0
        // NTSC: 263 lines, last_visible = 258. Walk to a point where target
        // would be 259..262 (sprite p-access fetches at cycle 1/3/5/7/9).
        // PAL has 312 visible lines so use NTSC where last_visible=258 to
        // exercise the early-return branch.
        for _ in 0..(263u32 * 65) {
            tick_vic(&mut vic, &memory);
        }
        // Simply ran one full NTSC frame; if no panic, the off-screen branch
        // was hit.
    }

    #[test]
    fn xscroll_zero_no_carry_load() {
        // Cover the xscroll==0 path explicitly with foreground bits to set
        // fg_mask via cell.fg_mask copy.
        let chargen = vec![0x80u8; 4096];
        let colour_ram = {
            let mut v = vec![0u8; 1024];
            v[0] = 0x07;
            v
        };
        let memory = TestMemory::with_colour(&chargen, colour_ram);
        let mut vic = Vic::new(VicModel::Pal6569);
        vic.write(0x11, 0x1B);
        vic.write(0x16, 0x08); // CSEL=1, xscroll=0
        vic.write(0x18, 0x14);
        vic.write(0x21, 0x02);
        let target_line = DISPLAY_START_LINE + 3;
        advance_to(&mut vic, &memory, target_line, DISPLAY_START_CYCLE);
        tick_vic(&mut vic, &memory);
        let fb_y = (target_line - FIRST_VISIBLE_LINE) as usize;
        let fb_x0 = (DISPLAY_START_CYCLE - FIRST_VISIBLE_CYCLE) as usize * 8;
        // High bit only set → first pixel = fg, rest = bg.
        assert_eq!(fb_pixel(&vic, fb_x0, fb_y), PALETTE[7]);
        assert_eq!(fb_pixel(&vic, fb_x0 + 1, fb_y), PALETTE[2]);
    }

    #[test]
    fn frame_complete_clears_lp_and_den_latches() {
        let (mut vic, memory) = make_vic_and_memory();
        // Trigger light pen.
        for _ in 0..40 {
            tick_vic(&mut vic, &memory);
        }
        vic.trigger_light_pen();
        assert!(vic.lp_triggered);
        // Run a full frame.
        let total = u32::from(LINES_PER_FRAME) * u32::from(CYCLES_PER_LINE);
        for _ in 0..total {
            tick_vic(&mut vic, &memory);
        }
        assert!(!vic.lp_triggered);
        assert!(!vic.den_latch);
    }

    #[test]
    fn raster_irq_compare_works_for_high_bit_lines() {
        // raster_compare > 255 — sets bit 8 via $D011 write.
        let (mut vic, memory) = make_vic_and_memory();
        // line 257 → low byte = 1, high bit = 1.
        vic.write(0x11, 0x80);
        vic.write(0x12, 1);
        vic.write(0x1A, 0x01);
        // Tick until raster matches.
        loop {
            tick_vic(&mut vic, &memory);
            if vic.irq_active() {
                break;
            }
            assert!(vic.raster_line() <= 258, "didn't fire");
        }
        assert_eq!(vic.raster_line(), 257);
    }
}
